package pe.edu.upeu.cochera.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.enums.EstadoUsuario;
import pe.edu.upeu.cochera.exception.RegistroDuplicadoException;
import pe.edu.upeu.cochera.model.Usuario;
import pe.edu.upeu.cochera.repository.ICrudGenericoRepository;
import pe.edu.upeu.cochera.repository.UsuarioRepository;
import pe.edu.upeu.cochera.service.IUsuarioService;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
public class UsuarioServiceImp extends CrudGenericoServiceImp<Usuario, Long> implements IUsuarioService {

    private final UsuarioRepository repo;

    @Override
    protected ICrudGenericoRepository<Usuario, Long> getRepo() {
        return repo;
    }

    @Override
    public Usuario save(Usuario usuario) {
        if (repo.buscarUsuario(usuario.getUsuario()).isPresent()) {
            throw new RegistroDuplicadoException("Ya existe un usuario llamado " + usuario.getUsuario());
        }
        return super.save(usuario);
    }

    @Override
    public Usuario update(Long id, Usuario usuario) {
        boolean repetido = repo.buscarUsuario(usuario.getUsuario())
                .filter(u -> !u.getIdUsuario().equals(id))
                .isPresent();
        if (repetido) {
            throw new RegistroDuplicadoException("Ya existe un usuario llamado " + usuario.getUsuario());
        }
        return super.update(id, usuario);
    }

    @Override
    public Optional<Usuario> loginUsuario(String usuario, String clave) {
        return repo.findByUsuarioAndClave(usuario, clave)
                .filter(u -> EstadoUsuario.ACTIVO.name().equals(u.getEstado()));
    }

    @Override
    public List<ComboBoxOption> listarEstados() {
        List<ComboBoxOption> lista = new ArrayList<>();
        for (EstadoUsuario e : EstadoUsuario.values()) {
            lista.add(new ComboBoxOption(e.name(), e.getDescripcion()));
        }
        return lista;
    }
}
