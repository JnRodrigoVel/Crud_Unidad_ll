package pe.edu.upeu.cochera.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.exception.RegistroDuplicadoException;
import pe.edu.upeu.cochera.model.TarjetaPropiedad;
import pe.edu.upeu.cochera.repository.ICrudGenericoRepository;
import pe.edu.upeu.cochera.repository.TarjetaPropiedadRepository;
import pe.edu.upeu.cochera.service.ITarjetaPropiedadService;

@RequiredArgsConstructor
public class TarjetaPropiedadServiceImp extends CrudGenericoServiceImp<TarjetaPropiedad, Long>
        implements ITarjetaPropiedadService {

    private final TarjetaPropiedadRepository repo;

    @Override
    protected ICrudGenericoRepository<TarjetaPropiedad, Long> getRepo() {
        return repo;
    }

    @Override
    public TarjetaPropiedad save(TarjetaPropiedad t) {
        validarNumero(null, t);
        return super.save(t);
    }

    @Override
    public TarjetaPropiedad update(Long id, TarjetaPropiedad t) {
        validarNumero(id, t);
        return super.update(id, t);
    }

    private void validarNumero(Long idActual, TarjetaPropiedad t) {
        boolean repetido = repo.buscarPorNumero(t.getNroTarjeta())
                .filter(otra -> !otra.getIdTarjeta().equals(idActual))
                .isPresent();
        if (repetido) {
            throw new RegistroDuplicadoException(
                    "Ya existe una tarjeta de propiedad con el número " + t.getNroTarjeta());
        }
    }
}
