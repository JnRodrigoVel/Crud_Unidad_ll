package pe.edu.upeu.cochera.enums;

import lombok.Getter;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/** Estado de un documento (SOAT / Revisión técnica) según su fecha de vencimiento. */
@Getter
public enum EstadoVigencia {
    VIGENTE("Vigente"),
    POR_VENCER("Por vencer"),
    VENCIDO("Vencido");

    public static final int DIAS_AVISO = 30;

    private final String descripcion;

    EstadoVigencia(String descripcion) {
        this.descripcion = descripcion;
    }

    public static EstadoVigencia de(LocalDate vencimiento) {
        if (vencimiento == null) return VENCIDO;
        long dias = ChronoUnit.DAYS.between(LocalDate.now(), vencimiento);
        if (dias < 0) return VENCIDO;
        if (dias <= DIAS_AVISO) return POR_VENCER;
        return VIGENTE;
    }

    public static Long diasRestantes(LocalDate vencimiento) {
        return vencimiento == null ? null : ChronoUnit.DAYS.between(LocalDate.now(), vencimiento);
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
