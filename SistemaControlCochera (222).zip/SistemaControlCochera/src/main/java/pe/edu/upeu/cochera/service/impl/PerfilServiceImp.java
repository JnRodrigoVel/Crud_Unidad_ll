package pe.edu.upeu.cochera.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.model.Perfil;
import pe.edu.upeu.cochera.repository.ICrudGenericoRepository;
import pe.edu.upeu.cochera.repository.PerfilRepository;
import pe.edu.upeu.cochera.service.IPerfilService;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class PerfilServiceImp extends CrudGenericoServiceImp<Perfil, Long> implements IPerfilService {

    private final PerfilRepository repo;

    @Override
    protected ICrudGenericoRepository<Perfil, Long> getRepo() {
        return repo;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> lista = new ArrayList<>();
        for (Perfil p : repo.findAll()) {
            lista.add(new ComboBoxOption(String.valueOf(p.getIdPerfil()), p.getNombre()));
        }
        return lista;
    }
}
