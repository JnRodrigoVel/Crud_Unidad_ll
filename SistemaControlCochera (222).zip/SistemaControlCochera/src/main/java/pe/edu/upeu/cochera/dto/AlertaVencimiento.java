package pe.edu.upeu.cochera.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AlertaVencimiento {
    private String placa;
    private String documento;
    private String numero;
    private String fechaVencimiento;
    private Long diasRestantes;
    private String estado;
}
