package pe.edu.upeu.cochera.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.components.ColumnInfo;
import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.model.Marca;
import pe.edu.upeu.cochera.service.ICrudGenericoService;
import pe.edu.upeu.cochera.service.IMarcaService;

import java.util.LinkedHashMap;
import java.util.Map;

@RequiredArgsConstructor
public class MarcaController extends BaseCrudController<Marca, Long> {

    private final IMarcaService ms;

    @FXML TextField txtNombre;

    @Override protected ICrudGenericoService<Marca, Long> servicio() { return ms; }

    @Override
    protected LinkedHashMap<String, ColumnInfo> columnas() {
        LinkedHashMap<String, ColumnInfo> c = new LinkedHashMap<>();
        c.put("ID", new ColumnInfo("idMarca", 70.0));
        c.put("Marca", new ColumnInfo("nombre", 250.0));
        return c;
    }

    @Override
    protected Marca leerFormulario() {
        return Marca.builder()
                .idMarca(enEdicion != null ? enEdicion.getIdMarca() : null)
                .nombre(texto(txtNombre))
                .build();
    }

    @Override protected void llenarFormulario(Marca m) { txtNombre.setText(m.getNombre()); }
    @Override protected void limpiarCampos() { txtNombre.clear(); }

    @Override
    protected Map<String, Control> camposValidables() {
        Map<String, Control> m = new LinkedHashMap<>();
        m.put("nombre", txtNombre);
        return m;
    }

    @Override protected Long idDe(Marca m) { return m.getIdMarca(); }
    @Override protected boolean coincideFiltro(Marca m, String f) { return m.getNombre().toLowerCase().contains(f); }
    @Override protected String descripcion(Marca m) { return "la marca " + m.getNombre(); }
}
