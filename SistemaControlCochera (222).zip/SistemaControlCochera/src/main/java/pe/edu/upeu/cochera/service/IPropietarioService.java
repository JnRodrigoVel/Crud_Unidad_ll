package pe.edu.upeu.cochera.service;

import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.model.Propietario;

import java.util.List;

public interface IPropietarioService extends ICrudGenericoService<Propietario, String> {
    List<ComboBoxOption> listarCombobox();
}
