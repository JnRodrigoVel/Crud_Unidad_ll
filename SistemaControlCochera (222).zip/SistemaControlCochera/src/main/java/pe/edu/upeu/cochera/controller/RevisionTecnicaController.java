package pe.edu.upeu.cochera.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.components.ColumnInfo;
import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.components.ComboBoxAutoComplete;
import pe.edu.upeu.cochera.enums.ResultadoRevision;
import pe.edu.upeu.cochera.model.RevisionTecnica;
import pe.edu.upeu.cochera.model.Vehiculo;
import pe.edu.upeu.cochera.service.ICrudGenericoService;
import pe.edu.upeu.cochera.service.IRevisionTecnicaService;
import pe.edu.upeu.cochera.service.IVehiculoService;
import pe.edu.upeu.cochera.utils.FechaUtil;

import java.util.LinkedHashMap;
import java.util.Map;

@RequiredArgsConstructor
public class RevisionTecnicaController extends BaseCrudController<RevisionTecnica, Long> {

    private final IRevisionTecnicaService rs;
    private final IVehiculoService vs;

    @FXML ComboBox<ComboBoxOption> cbxVehiculo, cbxResultado;
    @FXML TextField txtNroCertificado;
    @FXML DatePicker dpFechaRevision, dpFechaVencimiento;

    @Override
    protected void prepararFormulario() {
        cbxVehiculo.getItems().addAll(vs.listarCombobox());
        cbxResultado.getItems().addAll(rs.listarResultados());
        new ComboBoxAutoComplete<>(cbxVehiculo);
        FechaUtil.configurar(dpFechaRevision);
        FechaUtil.configurar(dpFechaVencimiento);
        txtNroCertificado.setTextFormatter(mayusculas());
    }

    @Override protected ICrudGenericoService<RevisionTecnica, Long> servicio() { return rs; }

    @Override
    protected LinkedHashMap<String, ColumnInfo> columnas() {
        LinkedHashMap<String, ColumnInfo> c = new LinkedHashMap<>();
        c.put("ID", new ColumnInfo("idRevision", 50.0));
        c.put("Placa", new ColumnInfo("vehiculo.placa", 100.0));
        c.put("N° Certificado", new ColumnInfo("nroCertificado", 130.0));
        c.put("Revisión", new ColumnInfo("fechaRevisionTxt", 100.0));
        c.put("Vence", new ColumnInfo("fechaVencimientoTxt", 100.0));
        c.put("Resultado", new ColumnInfo("resultado", 100.0));
        c.put("Días", new ColumnInfo("diasRestantes", 60.0));
        c.put("Estado", new ColumnInfo("estado", 90.0));
        return c;
    }

    @Override
    protected RevisionTecnica leerFormulario() {
        return RevisionTecnica.builder()
                .idRevision(enEdicion != null ? enEdicion.getIdRevision() : null)
                .vehiculo(elegido(cbxVehiculo, placa -> Vehiculo.builder().placa(placa).build()))
                .nroCertificado(texto(txtNroCertificado))
                .fechaRevision(fecha(dpFechaRevision))
                .fechaVencimiento(fecha(dpFechaVencimiento))
                .resultado(elegido(cbxResultado, ResultadoRevision::valueOf))
                .build();
    }

    @Override
    protected void llenarFormulario(RevisionTecnica r) {
        seleccionar(cbxVehiculo, r.getVehiculo().getPlaca());
        txtNroCertificado.setText(r.getNroCertificado());
        dpFechaRevision.setValue(r.getFechaRevision());
        dpFechaVencimiento.setValue(r.getFechaVencimiento());
        seleccionar(cbxResultado, r.getResultado() == null ? null : r.getResultado().name());
    }

    @Override
    protected void limpiarCampos() {
        cbxVehiculo.getSelectionModel().clearSelection();
        cbxResultado.getSelectionModel().clearSelection();
        txtNroCertificado.clear();
        dpFechaRevision.setValue(null);
        dpFechaVencimiento.setValue(null);
    }

    @Override
    protected Map<String, Control> camposValidables() {
        Map<String, Control> m = new LinkedHashMap<>();
        m.put("vehiculo", cbxVehiculo);
        m.put("nroCertificado", txtNroCertificado);
        m.put("fechaRevision", dpFechaRevision);
        m.put("fechaVencimiento", dpFechaVencimiento);
        m.put("vigenciaValida", dpFechaVencimiento);
        m.put("resultado", cbxResultado);
        return m;
    }

    @Override protected Long idDe(RevisionTecnica r) { return r.getIdRevision(); }

    @Override
    protected boolean coincideFiltro(RevisionTecnica r, String f) {
        return r.getVehiculo().getPlaca().toLowerCase().contains(f)
                || r.getNroCertificado().toLowerCase().contains(f)
                || r.getEstado().toLowerCase().contains(f);
    }

    @Override
    protected String descripcion(RevisionTecnica r) {
        return "la revisión " + r.getNroCertificado() + " del vehículo " + r.getVehiculo().getPlaca();
    }
}
