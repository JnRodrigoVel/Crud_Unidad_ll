package pe.edu.upeu.cochera.service;

import pe.edu.upeu.cochera.model.Soat;

public interface ISoatService extends ICrudGenericoService<Soat, Long> {
}
