package pe.edu.upeu.cochera.service;

import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.model.Perfil;

import java.util.List;

public interface IPerfilService extends ICrudGenericoService<Perfil, Long> {
    List<ComboBoxOption> listarCombobox();
}
