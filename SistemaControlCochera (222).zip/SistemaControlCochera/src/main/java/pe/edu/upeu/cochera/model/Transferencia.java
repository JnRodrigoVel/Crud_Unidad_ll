package pe.edu.upeu.cochera.model;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.cochera.utils.FechaUtil;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Transferencia {
    private Long idTransf;
    @NotNull(message = "El vehículo es obligatorio")
    private Vehiculo vehiculo;
    @NotNull(message = "El nuevo propietario es obligatorio")
    private Propietario nuevoPropietario;
    @NotNull(message = "La fecha de transferencia es obligatoria")
    private LocalDate fechaTransf;
    @NotNull(message = "El monto es obligatorio")
    @DecimalMin(value = "0.0", message = "El monto no puede ser negativo")
    private BigDecimal monto;
    @NotNull(message = "No hay un usuario en sesión")
    private Usuario usuario;

    public String getFechaTransfTxt() {
        return FechaUtil.formatear(fechaTransf);
    }
}
