package pe.edu.upeu.cochera.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.cochera.utils.FechaUtil;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TarjetaPropiedad {
    private Long idTarjeta;
    @NotNull(message = "El vehículo es obligatorio")
    private Vehiculo vehiculo;
    @NotBlank(message = "El número de tarjeta es obligatorio")
    @Size(max = 15, message = "El número de tarjeta admite máximo 15 caracteres")
    private String nroTarjeta;
    @NotNull(message = "La fecha de emisión es obligatoria")
    private LocalDate fechaEmision;

    public String getFechaEmisionTxt() {
        return FechaUtil.formatear(fechaEmision);
    }
}
