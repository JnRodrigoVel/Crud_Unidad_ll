package pe.edu.upeu.cochera.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.model.Marca;
import pe.edu.upeu.cochera.repository.ICrudGenericoRepository;
import pe.edu.upeu.cochera.repository.MarcaRepository;
import pe.edu.upeu.cochera.service.IMarcaService;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class MarcaServiceImp extends CrudGenericoServiceImp<Marca, Long> implements IMarcaService {

    private final MarcaRepository repo;

    @Override
    protected ICrudGenericoRepository<Marca, Long> getRepo() {
        return repo;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> lista = new ArrayList<>();
        for (Marca m : repo.findAll()) {
            lista.add(new ComboBoxOption(String.valueOf(m.getIdMarca()), m.getNombre()));
        }
        return lista;
    }
}
