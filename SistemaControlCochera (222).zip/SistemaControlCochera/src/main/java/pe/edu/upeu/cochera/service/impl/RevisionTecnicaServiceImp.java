package pe.edu.upeu.cochera.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.enums.ResultadoRevision;
import pe.edu.upeu.cochera.exception.RegistroDuplicadoException;
import pe.edu.upeu.cochera.model.RevisionTecnica;
import pe.edu.upeu.cochera.repository.ICrudGenericoRepository;
import pe.edu.upeu.cochera.repository.RevisionTecnicaRepository;
import pe.edu.upeu.cochera.service.IRevisionTecnicaService;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class RevisionTecnicaServiceImp extends CrudGenericoServiceImp<RevisionTecnica, Long>
        implements IRevisionTecnicaService {

    private final RevisionTecnicaRepository repo;

    @Override
    protected ICrudGenericoRepository<RevisionTecnica, Long> getRepo() {
        return repo;
    }

    @Override
    public RevisionTecnica save(RevisionTecnica r) {
        validarCertificado(null, r);
        return super.save(r);
    }

    @Override
    public RevisionTecnica update(Long id, RevisionTecnica r) {
        validarCertificado(id, r);
        return super.update(id, r);
    }

    private void validarCertificado(Long idActual, RevisionTecnica r) {
        boolean repetido = repo.buscarPorCertificado(r.getNroCertificado())
                .filter(otra -> !otra.getIdRevision().equals(idActual))
                .isPresent();
        if (repetido) {
            throw new RegistroDuplicadoException(
                    "Ya existe una revisión con el certificado " + r.getNroCertificado());
        }
    }

    @Override
    public List<ComboBoxOption> listarResultados() {
        List<ComboBoxOption> lista = new ArrayList<>();
        for (ResultadoRevision r : ResultadoRevision.values()) {
            lista.add(new ComboBoxOption(r.name(), r.getDescripcion()));
        }
        return lista;
    }
}
