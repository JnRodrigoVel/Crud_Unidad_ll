package pe.edu.upeu.cochera.service;

import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.model.Usuario;

import java.util.List;
import java.util.Optional;

public interface IUsuarioService extends ICrudGenericoService<Usuario, Long> {
    Optional<Usuario> loginUsuario(String usuario, String clave);
    List<ComboBoxOption> listarEstados();
}
