package pe.edu.upeu.cochera.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Propietario {
    @NotBlank(message = "El DNI es obligatorio")
    @Pattern(regexp = "^\\d{8}$", message = "El DNI debe tener 8 dígitos")
    private String dni;
    @NotBlank(message = "El nombre es obligatorio")
    @Size(max = 50, message = "El nombre admite máximo 50 caracteres")
    private String nombre;
    @Size(max = 60, message = "La dirección admite máximo 60 caracteres")
    private String direccion;
    @Pattern(regexp = "^(\\d{9})?$", message = "El celular debe tener 9 dígitos")
    private String celular;
}
