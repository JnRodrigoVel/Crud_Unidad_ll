package pe.edu.upeu.cochera.model;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.cochera.enums.EstadoVigencia;
import pe.edu.upeu.cochera.utils.FechaUtil;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Soat {
    private Long idSoat;
    @NotNull(message = "El vehículo es obligatorio")
    private Vehiculo vehiculo;
    @NotBlank(message = "El número de póliza es obligatorio")
    @Size(max = 20, message = "El número de póliza admite máximo 20 caracteres")
    private String nroPoliza;
    @NotBlank(message = "La aseguradora es obligatoria")
    @Size(max = 40, message = "La aseguradora admite máximo 40 caracteres")
    private String aseguradora;
    @NotNull(message = "La fecha de inicio es obligatoria")
    private LocalDate fechaInicio;
    @NotNull(message = "La fecha de vencimiento es obligatoria")
    private LocalDate fechaVencimiento;

    @AssertTrue(message = "El vencimiento debe ser posterior a la fecha de inicio")
    public boolean isVigenciaValida() {
        return fechaInicio == null || fechaVencimiento == null || fechaVencimiento.isAfter(fechaInicio);
    }

    public String getFechaInicioTxt() {
        return FechaUtil.formatear(fechaInicio);
    }

    public String getFechaVencimientoTxt() {
        return FechaUtil.formatear(fechaVencimiento);
    }

    public Long getDiasRestantes() {
        return EstadoVigencia.diasRestantes(fechaVencimiento);
    }

    public String getEstado() {
        return EstadoVigencia.de(fechaVencimiento).getDescripcion();
    }
}
