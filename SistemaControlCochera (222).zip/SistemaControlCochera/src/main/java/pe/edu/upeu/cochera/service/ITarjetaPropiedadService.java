package pe.edu.upeu.cochera.service;

import pe.edu.upeu.cochera.model.TarjetaPropiedad;

public interface ITarjetaPropiedadService extends ICrudGenericoService<TarjetaPropiedad, Long> {
}
