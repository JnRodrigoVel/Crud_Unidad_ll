package pe.edu.upeu.cochera.repository;

import pe.edu.upeu.cochera.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class UsuarioRepository extends AbstractJpaRepository<Usuario, Long> {

    private static final String SELECT_JOIN =
            "SELECT u.*, p.nombre AS perfil_nombre, p.codigo AS perfil_codigo " +
                    "FROM usuario u JOIN perfil p ON u.id_perfil = p.id_perfil ";

    @Override protected String getTableName() { return "usuario"; }
    @Override protected String getPkColumn() { return "id_usuario"; }

    @Override
    public List<Usuario> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY u.usuario");
    }

    @Override
    public Optional<Usuario> findById(Long id) {
        return executeQueryOne(SELECT_JOIN + "WHERE u.id_usuario = ?", id);
    }

    @Override
    protected Usuario mapRow(ResultSet rs) throws SQLException {
        Perfil perfil = Perfil.builder()
                .idPerfil(rs.getLong("id_perfil"))
                .nombre(rs.getString("perfil_nombre"))
                .codigo(rs.getString("perfil_codigo"))
                .build();
        return Usuario.builder()
                .idUsuario(rs.getLong("id_usuario"))
                .usuario(rs.getString("usuario"))
                .clave(rs.getString("clave"))
                .estado(rs.getString("estado"))
                .perfil(perfil)
                .build();
    }

    public Optional<Usuario> buscarUsuario(String usuario) {
        return executeQueryOne(SELECT_JOIN + "WHERE u.usuario = ?", usuario);
    }

    public Optional<Usuario> findByUsuarioAndClave(String usuario, String clave) {
        return executeQueryOne(SELECT_JOIN + "WHERE u.usuario = ? AND u.clave = ?", usuario, clave);
    }

    @Override
    protected Usuario insert(Connection conn, Usuario e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO usuario(usuario,clave,estado,id_perfil) VALUES(?,?,?,?)",
                e.getUsuario(), e.getClave(), e.getEstado(), e.getPerfil().getIdPerfil());
        e.setIdUsuario(id);
        return e;
    }

    @Override
    protected Usuario updateRow(Connection conn, Usuario e) throws SQLException {
        executeUpdate(conn,
                "UPDATE usuario SET usuario=?,clave=?,estado=?,id_perfil=? WHERE id_usuario=?",
                e.getUsuario(), e.getClave(), e.getEstado(), e.getPerfil().getIdPerfil(), e.getIdUsuario());
        return e;
    }
}
