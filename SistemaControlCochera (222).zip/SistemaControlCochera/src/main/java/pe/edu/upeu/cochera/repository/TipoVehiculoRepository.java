package pe.edu.upeu.cochera.repository;

import pe.edu.upeu.cochera.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class TipoVehiculoRepository extends AbstractJpaRepository<TipoVehiculo, Long> {

    @Override protected String getTableName() { return "tipo_vehiculo"; }
    @Override protected String getPkColumn() { return "id_tipo"; }

    @Override
    public List<TipoVehiculo> findAll() {
        return executeQuery("SELECT * FROM tipo_vehiculo ORDER BY nombre");
    }

    @Override
    protected TipoVehiculo mapRow(ResultSet rs) throws SQLException {
        return TipoVehiculo.builder()
                .idTipo(rs.getLong("id_tipo"))
                .nombre(rs.getString("nombre"))
                .build();
    }

    @Override
    protected TipoVehiculo insert(Connection conn, TipoVehiculo e) throws SQLException {
        long id = executeInsertGetKey(conn, "INSERT INTO tipo_vehiculo(nombre) VALUES(?)", e.getNombre());
        e.setIdTipo(id);
        return e;
    }

    @Override
    protected TipoVehiculo updateRow(Connection conn, TipoVehiculo e) throws SQLException {
        executeUpdate(conn, "UPDATE tipo_vehiculo SET nombre=? WHERE id_tipo=?", e.getNombre(), e.getIdTipo());
        return e;
    }
}
