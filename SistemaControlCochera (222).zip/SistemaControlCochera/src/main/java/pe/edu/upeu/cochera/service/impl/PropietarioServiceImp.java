package pe.edu.upeu.cochera.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.exception.RegistroDuplicadoException;
import pe.edu.upeu.cochera.model.Propietario;
import pe.edu.upeu.cochera.repository.ICrudGenericoRepository;
import pe.edu.upeu.cochera.repository.PropietarioRepository;
import pe.edu.upeu.cochera.service.IPropietarioService;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class PropietarioServiceImp extends CrudGenericoServiceImp<Propietario, String>
        implements IPropietarioService {

    private final PropietarioRepository repo;

    @Override
    protected ICrudGenericoRepository<Propietario, String> getRepo() {
        return repo;
    }

    // el DNI debe ser único
    @Override
    public Propietario save(Propietario propietario) {
        if (repo.existsById(propietario.getDni())) {
            throw new RegistroDuplicadoException(
                    "Ya existe un propietario registrado con el DNI " + propietario.getDni());
        }
        return super.save(propietario);
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> lista = new ArrayList<>();
        for (Propietario p : repo.findAll()) {
            lista.add(new ComboBoxOption(p.getDni(), p.getDni() + " - " + p.getNombre()));
        }
        return lista;
    }
}
