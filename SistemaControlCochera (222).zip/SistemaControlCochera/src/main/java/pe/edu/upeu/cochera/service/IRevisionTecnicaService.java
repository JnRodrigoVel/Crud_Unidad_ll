package pe.edu.upeu.cochera.service;

import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.model.RevisionTecnica;

import java.util.List;

public interface IRevisionTecnicaService extends ICrudGenericoService<RevisionTecnica, Long> {
    List<ComboBoxOption> listarResultados();
}
