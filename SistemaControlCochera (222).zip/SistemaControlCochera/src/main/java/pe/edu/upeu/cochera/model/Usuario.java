package pe.edu.upeu.cochera.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Usuario {
    private Long idUsuario;
    @NotBlank(message = "El usuario es obligatorio")
    @Size(min = 3, max = 30, message = "El usuario debe tener entre 3 y 30 caracteres")
    private String usuario;
    @NotBlank(message = "La clave es obligatoria")
    @Size(min = 6, max = 30, message = "La clave debe tener entre 6 y 30 caracteres")
    private String clave;
    @NotNull(message = "El perfil es obligatorio")
    private Perfil perfil;
    @NotBlank(message = "El estado es obligatorio")
    private String estado;
}
