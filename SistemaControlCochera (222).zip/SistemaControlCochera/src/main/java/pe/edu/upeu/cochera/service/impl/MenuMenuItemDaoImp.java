package pe.edu.upeu.cochera.service.impl;

import pe.edu.upeu.cochera.dto.MenuMenuItenTO;
import pe.edu.upeu.cochera.service.IMenuMenuItemDao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MenuMenuItemDaoImp implements IMenuMenuItemDao {

    private static final String ROOT = "Root";
    private static final String ADMIN = "Administrador";
    private static final String REPORTE = "Reporte";

    /** Una opción del menú y los perfiles que pueden usarla. */
    private record Opcion(MenuMenuItenTO acceso, Set<String> perfiles) {
    }

    private static Opcion op(String id, String ruta, String menu, String item,
                             String tab, String tipo, String... perfiles) {
        return new Opcion(new MenuMenuItenTO(id, ruta, menu, item, tab, tipo), Set.of(perfiles));
    }

    @Override
    public List<MenuMenuItenTO> listaAccesos(String perfil) {
        List<Opcion> todas = List.of(
                op("mialertas", "/view/main_alertas.fxml", "Principal", "Alertas de vencimiento",
                        "Alertas de vencimiento", "T", ROOT, ADMIN, REPORTE),
                op("misalir", "/view/login.fxml", "Principal", "Cerrar sesión",
                        "Salir", "C", ROOT, ADMIN, REPORTE),

                op("mipropietario", "/view/main_propietario.fxml", "Registros", "Propietarios",
                        "Adm. Propietarios", "T", ROOT, ADMIN),
                op("mimarca", "/view/main_marca.fxml", "Registros", "Marcas",
                        "Adm. Marcas", "T", ROOT, ADMIN),
                op("mitipo", "/view/main_tipovehiculo.fxml", "Registros", "Tipos de vehículo",
                        "Adm. Tipos de vehículo", "T", ROOT, ADMIN),
                op("mivehiculo", "/view/main_vehiculo.fxml", "Registros", "Vehículos",
                        "Adm. Vehículos", "T", ROOT, ADMIN, REPORTE),

                op("mitarjeta", "/view/main_tarjeta.fxml", "Documentos", "Tarjeta de propiedad",
                        "Tarjeta de propiedad", "T", ROOT, ADMIN, REPORTE),
                op("misoat", "/view/main_soat.fxml", "Documentos", "SOAT",
                        "SOAT", "T", ROOT, ADMIN, REPORTE),
                op("mirevision", "/view/main_revision.fxml", "Documentos", "Revisión técnica",
                        "Revisión técnica", "T", ROOT, ADMIN, REPORTE),

                op("mitransferencia", "/view/main_transferencia.fxml", "Movimientos", "Transferencias",
                        "Transferencias", "T", ROOT, ADMIN),

                op("miusuario", "/view/main_usuario.fxml", "Seguridad", "Usuarios",
                        "Adm. Usuarios", "T", ROOT)
        );

        List<MenuMenuItenTO> accesos = new ArrayList<>();
        for (Opcion o : todas) {
            if (o.perfiles().contains(perfil)) {
                accesos.add(o.acceso());
            }
        }
        return accesos;
    }

    @Override
    public Map<String, String[]> accesosAutorizados(List<MenuMenuItenTO> accesos) {
        Map<String, String[]> menuConfig = new HashMap<>();
        for (MenuMenuItenTO a : accesos) {
            menuConfig.put("mi" + a.getIdNombreObj().substring(2),
                    new String[]{a.getRutaFile(), a.getNombreTab(), a.getTipoTab()});
        }
        return menuConfig;
    }
}
