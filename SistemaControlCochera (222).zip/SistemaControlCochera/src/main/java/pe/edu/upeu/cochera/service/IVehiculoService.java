package pe.edu.upeu.cochera.service;

import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.model.Vehiculo;

import java.util.List;

public interface IVehiculoService extends ICrudGenericoService<Vehiculo, String> {
    List<ComboBoxOption> listarColores();
    /** Vehículos para los combos de documentos y transferencias (clave = placa). */
    List<ComboBoxOption> listarCombobox();
}
