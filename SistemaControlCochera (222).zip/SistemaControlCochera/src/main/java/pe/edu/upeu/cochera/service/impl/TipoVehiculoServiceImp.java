package pe.edu.upeu.cochera.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.model.TipoVehiculo;
import pe.edu.upeu.cochera.repository.ICrudGenericoRepository;
import pe.edu.upeu.cochera.repository.TipoVehiculoRepository;
import pe.edu.upeu.cochera.service.ITipoVehiculoService;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class TipoVehiculoServiceImp extends CrudGenericoServiceImp<TipoVehiculo, Long>
        implements ITipoVehiculoService {

    private final TipoVehiculoRepository repo;

    @Override
    protected ICrudGenericoRepository<TipoVehiculo, Long> getRepo() {
        return repo;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> lista = new ArrayList<>();
        for (TipoVehiculo t : repo.findAll()) {
            lista.add(new ComboBoxOption(String.valueOf(t.getIdTipo()), t.getNombre()));
        }
        return lista;
    }
}
