package pe.edu.upeu.cochera.repository;

import pe.edu.upeu.cochera.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class TransferenciaRepository extends AbstractJpaRepository<Transferencia, Long> {

    private static final String SELECT_JOIN =
            "SELECT t.*, p.nombre AS prop_nombre, u.usuario AS usu_nombre FROM transferencia t " +
                    "JOIN propietario p ON t.dni_nuevo = p.dni " +
                    "JOIN usuario u ON t.id_usuario = u.id_usuario ";

    @Override protected String getTableName() { return "transferencia"; }
    @Override protected String getPkColumn() { return "id_transf"; }

    @Override
    public List<Transferencia> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY t.fecha_transf DESC, t.id_transf DESC");
    }

    @Override
    public Optional<Transferencia> findById(Long id) {
        return executeQueryOne(SELECT_JOIN + "WHERE t.id_transf = ?", id);
    }

    @Override
    protected Transferencia mapRow(ResultSet rs) throws SQLException {
        return Transferencia.builder()
                .idTransf(rs.getLong("id_transf"))
                .vehiculo(Vehiculo.builder().placa(rs.getString("placa")).build())
                .nuevoPropietario(Propietario.builder()
                        .dni(rs.getString("dni_nuevo"))
                        .nombre(rs.getString("prop_nombre")).build())
                .fechaTransf(getFecha(rs, "fecha_transf"))
                .monto(rs.getBigDecimal("monto"))
                .usuario(Usuario.builder()
                        .idUsuario(rs.getLong("id_usuario"))
                        .usuario(rs.getString("usu_nombre")).build())
                .build();
    }

    /** Registra la transferencia y cambia el propietario del vehículo en la misma transacción. */
    @Override
    protected Transferencia insert(Connection conn, Transferencia e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO transferencia(placa,dni_nuevo,fecha_transf,monto,id_usuario) VALUES(?,?,?,?,?)",
                e.getVehiculo().getPlaca(), e.getNuevoPropietario().getDni(),
                e.getFechaTransf(), e.getMonto(), e.getUsuario().getIdUsuario());
        executeUpdate(conn, "UPDATE vehiculo SET dni=? WHERE placa=?",
                e.getNuevoPropietario().getDni(), e.getVehiculo().getPlaca());
        e.setIdTransf(id);
        return e;
    }

    /** Al editar solo se corrigen fecha y monto; el vehículo y el nuevo propietario no cambian. */
    @Override
    protected Transferencia updateRow(Connection conn, Transferencia e) throws SQLException {
        executeUpdate(conn, "UPDATE transferencia SET fecha_transf=?,monto=? WHERE id_transf=?",
                e.getFechaTransf(), e.getMonto(), e.getIdTransf());
        return e;
    }
}
