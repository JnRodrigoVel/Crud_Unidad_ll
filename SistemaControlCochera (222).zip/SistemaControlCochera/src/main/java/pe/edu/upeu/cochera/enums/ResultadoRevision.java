package pe.edu.upeu.cochera.enums;

import lombok.Getter;

@Getter
public enum ResultadoRevision {
    APROBADO("Aprobado"),
    OBSERVADO("Observado"),
    DESAPROBADO("Desaprobado");

    private final String descripcion;

    ResultadoRevision(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
