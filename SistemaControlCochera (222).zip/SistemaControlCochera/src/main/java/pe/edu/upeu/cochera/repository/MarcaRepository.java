package pe.edu.upeu.cochera.repository;

import pe.edu.upeu.cochera.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class MarcaRepository extends AbstractJpaRepository<Marca, Long> {

    @Override protected String getTableName() { return "marca"; }
    @Override protected String getPkColumn() { return "id_marca"; }

    @Override
    public List<Marca> findAll() {
        return executeQuery("SELECT * FROM marca ORDER BY nombre");
    }

    @Override
    protected Marca mapRow(ResultSet rs) throws SQLException {
        return Marca.builder()
                .idMarca(rs.getLong("id_marca"))
                .nombre(rs.getString("nombre"))
                .build();
    }

    @Override
    protected Marca insert(Connection conn, Marca e) throws SQLException {
        long id = executeInsertGetKey(conn, "INSERT INTO marca(nombre) VALUES(?)", e.getNombre());
        e.setIdMarca(id);
        return e;
    }

    @Override
    protected Marca updateRow(Connection conn, Marca e) throws SQLException {
        executeUpdate(conn, "UPDATE marca SET nombre=? WHERE id_marca=?", e.getNombre(), e.getIdMarca());
        return e;
    }
}
