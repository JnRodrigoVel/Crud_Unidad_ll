package pe.edu.upeu.cochera.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.components.ColumnInfo;
import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.model.TipoVehiculo;
import pe.edu.upeu.cochera.service.ICrudGenericoService;
import pe.edu.upeu.cochera.service.ITipoVehiculoService;

import java.util.LinkedHashMap;
import java.util.Map;

@RequiredArgsConstructor
public class TipoVehiculoController extends BaseCrudController<TipoVehiculo, Long> {

    private final ITipoVehiculoService ts;

    @FXML TextField txtNombre;

    @Override protected ICrudGenericoService<TipoVehiculo, Long> servicio() { return ts; }

    @Override
    protected LinkedHashMap<String, ColumnInfo> columnas() {
        LinkedHashMap<String, ColumnInfo> c = new LinkedHashMap<>();
        c.put("ID", new ColumnInfo("idTipo", 70.0));
        c.put("Tipo de vehículo", new ColumnInfo("nombre", 250.0));
        return c;
    }

    @Override
    protected TipoVehiculo leerFormulario() {
        return TipoVehiculo.builder()
                .idTipo(enEdicion != null ? enEdicion.getIdTipo() : null)
                .nombre(texto(txtNombre))
                .build();
    }

    @Override protected void llenarFormulario(TipoVehiculo t) { txtNombre.setText(t.getNombre()); }
    @Override protected void limpiarCampos() { txtNombre.clear(); }

    @Override
    protected Map<String, Control> camposValidables() {
        Map<String, Control> m = new LinkedHashMap<>();
        m.put("nombre", txtNombre);
        return m;
    }

    @Override protected Long idDe(TipoVehiculo t) { return t.getIdTipo(); }
    @Override protected boolean coincideFiltro(TipoVehiculo t, String f) { return t.getNombre().toLowerCase().contains(f); }
    @Override protected String descripcion(TipoVehiculo t) { return "el tipo " + t.getNombre(); }
}
