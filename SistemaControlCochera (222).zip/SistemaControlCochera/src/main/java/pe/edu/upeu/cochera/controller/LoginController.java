package pe.edu.upeu.cochera.controller;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Screen;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.SistemaCochera;
import pe.edu.upeu.cochera.components.Toast;
import pe.edu.upeu.cochera.config.AppContext;
import pe.edu.upeu.cochera.config.DatabaseConfig;
import pe.edu.upeu.cochera.dto.SessionManager;
import pe.edu.upeu.cochera.model.Usuario;
import pe.edu.upeu.cochera.service.IUsuarioService;

@RequiredArgsConstructor
public class LoginController {

    private final IUsuarioService us;

    @FXML
    TextField txtUsuario;

    @FXML
    PasswordField txtClave;

    @FXML
    public void initialize() {
        txtUsuario.clear();
        txtClave.clear();
    }

    @FXML
    public void login(ActionEvent e) {
        us.loginUsuario(txtUsuario.getText().trim(), txtClave.getText())
                .ifPresentOrElse(
                        usuario -> abrirPantalla(e, usuario),
                        () -> mensaje(e, "Usuario o clave incorrectos, o el usuario está inactivo"));
    }

    public void mensaje(ActionEvent e, String msg) {
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        Toast.showToast(stage, msg, 2000, w, h);
    }

    @FXML
    public void logout() {
        DatabaseConfig.shutdown();
        Platform.exit();
        System.exit(0);
    }

    public void abrirPantalla(ActionEvent e, Usuario usuario) {
        SessionManager.getInstance().setUserId(usuario.getIdUsuario());
        SessionManager.getInstance().setUserName(usuario.getUsuario());
        SessionManager.getInstance().setUserPerfil(usuario.getPerfil().getNombre());

        try {
            Rectangle2D pantalla = Screen.getPrimary().getVisualBounds();
            FXMLLoader fxmlLoader = new FXMLLoader(SistemaCochera.class.getResource("/view/maingui.fxml"));
            fxmlLoader.setControllerFactory(AppContext.getInstance()::getBean);
            Scene scene = new Scene(fxmlLoader.load(), pantalla.getWidth(), pantalla.getHeight());
            scene.getStylesheets().add(SistemaCochera.class.getResource("/css/style.css").toExternalForm());
            Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
            stage.setTitle("Sistema de Control Cochera");
            stage.setScene(scene);
            stage.setX(pantalla.getMinX());
            stage.setY(pantalla.getMinY());
            stage.setResizable(true);
            stage.show();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
