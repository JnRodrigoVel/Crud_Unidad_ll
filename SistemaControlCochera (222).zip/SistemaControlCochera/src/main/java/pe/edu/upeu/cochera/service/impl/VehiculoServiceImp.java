package pe.edu.upeu.cochera.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.enums.ColorVehiculo;
import pe.edu.upeu.cochera.exception.RegistroDuplicadoException;
import pe.edu.upeu.cochera.model.Vehiculo;
import pe.edu.upeu.cochera.repository.ICrudGenericoRepository;
import pe.edu.upeu.cochera.repository.VehiculoRepository;
import pe.edu.upeu.cochera.service.IVehiculoService;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class VehiculoServiceImp extends CrudGenericoServiceImp<Vehiculo, String> implements IVehiculoService {

    private final VehiculoRepository repo;

    @Override
    protected ICrudGenericoRepository<Vehiculo, String> getRepo() {
        return repo;
    }

    // la placa debe ser única
    @Override
    public Vehiculo save(Vehiculo vehiculo) {
        if (repo.existsById(vehiculo.getPlaca())) {
            throw new RegistroDuplicadoException(
                    "Ya existe un vehículo registrado con la placa " + vehiculo.getPlaca());
        }
        return super.save(vehiculo);
    }

    @Override
    public List<ComboBoxOption> listarColores() {
        List<ComboBoxOption> lista = new ArrayList<>();
        for (ColorVehiculo c : ColorVehiculo.values()) {
            lista.add(new ComboBoxOption(c.name(), c.getDescripcion()));
        }
        return lista;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> lista = new ArrayList<>();
        for (Vehiculo v : repo.findAll()) {
            lista.add(new ComboBoxOption(v.getPlaca(),
                    v.getPlaca() + " - " + v.getMarca().getNombre() + " " + v.getModelo()));
        }
        return lista;
    }
}
