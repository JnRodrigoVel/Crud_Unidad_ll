package pe.edu.upeu.cochera.repository;

import pe.edu.upeu.cochera.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class SoatRepository extends AbstractJpaRepository<Soat, Long> {

    private static final String SELECT_JOIN =
            "SELECT s.*, v.modelo AS veh_modelo FROM soat s " +
                    "JOIN vehiculo v ON s.placa = v.placa ";

    @Override protected String getTableName() { return "soat"; }
    @Override protected String getPkColumn() { return "id_soat"; }

    @Override
    public List<Soat> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY s.fecha_vencimiento");
    }

    @Override
    public Optional<Soat> findById(Long id) {
        return executeQueryOne(SELECT_JOIN + "WHERE s.id_soat = ?", id);
    }

    public Optional<Soat> buscarPorPoliza(String nroPoliza) {
        return executeQueryOne(SELECT_JOIN + "WHERE s.nro_poliza = ?", nroPoliza);
    }

    @Override
    protected Soat mapRow(ResultSet rs) throws SQLException {
        return Soat.builder()
                .idSoat(rs.getLong("id_soat"))
                .vehiculo(Vehiculo.builder()
                        .placa(rs.getString("placa"))
                        .modelo(rs.getString("veh_modelo")).build())
                .nroPoliza(rs.getString("nro_poliza"))
                .aseguradora(rs.getString("aseguradora"))
                .fechaInicio(getFecha(rs, "fecha_inicio"))
                .fechaVencimiento(getFecha(rs, "fecha_vencimiento"))
                .build();
    }

    @Override
    protected Soat insert(Connection conn, Soat e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO soat(placa,nro_poliza,aseguradora,fecha_inicio,fecha_vencimiento) VALUES(?,?,?,?,?)",
                e.getVehiculo().getPlaca(), e.getNroPoliza(), e.getAseguradora(),
                e.getFechaInicio(), e.getFechaVencimiento());
        e.setIdSoat(id);
        return e;
    }

    @Override
    protected Soat updateRow(Connection conn, Soat e) throws SQLException {
        executeUpdate(conn,
                "UPDATE soat SET placa=?,nro_poliza=?,aseguradora=?,fecha_inicio=?,fecha_vencimiento=? WHERE id_soat=?",
                e.getVehiculo().getPlaca(), e.getNroPoliza(), e.getAseguradora(),
                e.getFechaInicio(), e.getFechaVencimiento(), e.getIdSoat());
        return e;
    }
}
