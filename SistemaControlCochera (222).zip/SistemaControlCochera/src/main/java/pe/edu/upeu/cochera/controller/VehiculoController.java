package pe.edu.upeu.cochera.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.components.ColumnInfo;
import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.components.ComboBoxAutoComplete;
import pe.edu.upeu.cochera.enums.ColorVehiculo;
import pe.edu.upeu.cochera.model.Vehiculo;
import pe.edu.upeu.cochera.service.*;

import java.util.LinkedHashMap;
import java.util.Map;

@RequiredArgsConstructor
public class VehiculoController extends BaseCrudController<Vehiculo, String> {

    private final IVehiculoService vs;
    private final IMarcaService ms;
    private final ITipoVehiculoService ts;
    private final IPropietarioService ps;

    @FXML TextField txtPlaca, txtModelo, txtAnio, txtNroMotor;
    @FXML ComboBox<ComboBoxOption> cbxMarca, cbxTipo, cbxPropietario, cbxColor;

    @Override
    protected void prepararFormulario() {
        cbxMarca.getItems().addAll(ms.listarCombobox());
        cbxTipo.getItems().addAll(ts.listarCombobox());
        cbxPropietario.getItems().addAll(ps.listarCombobox());
        cbxColor.getItems().addAll(vs.listarColores());
        new ComboBoxAutoComplete<>(cbxPropietario);

        txtPlaca.setTextFormatter(mayusculas());
        txtAnio.setTextFormatter(soloDigitos(4));
    }

    @Override protected ICrudGenericoService<Vehiculo, String> servicio() { return vs; }

    @Override
    protected LinkedHashMap<String, ColumnInfo> columnas() {
        LinkedHashMap<String, ColumnInfo> c = new LinkedHashMap<>();
        c.put("Placa", new ColumnInfo("placa", 100.0));
        c.put("Marca", new ColumnInfo("marca.nombre", 110.0));
        c.put("Tipo", new ColumnInfo("tipo.nombre", 110.0));
        c.put("Modelo", new ColumnInfo("modelo", 110.0));
        c.put("Año", new ColumnInfo("anio", 60.0));
        c.put("Color", new ColumnInfo("color", 90.0));
        c.put("Propietario", new ColumnInfo("propietario.nombre", 180.0));
        c.put("N° Motor", new ColumnInfo("nroMotor", 120.0));
        return c;
    }

    @Override
    protected Vehiculo leerFormulario() {
        return Vehiculo.builder()
                .placa(enEdicion != null ? enEdicion.getPlaca() : texto(txtPlaca).toUpperCase())
                .marca(elegido(cbxMarca, k -> ms.findById(Long.parseLong(k))))
                .tipo(elegido(cbxTipo, k -> ts.findById(Long.parseLong(k))))
                .propietario(elegido(cbxPropietario, ps::findById))
                .modelo(texto(txtModelo))
                .anio(entero(txtAnio))
                .color(elegido(cbxColor, ColorVehiculo::valueOf))
                .nroMotor(texto(txtNroMotor))
                .build();
    }

    @Override
    protected void llenarFormulario(Vehiculo v) {
        txtPlaca.setText(v.getPlaca());
        seleccionar(cbxMarca, String.valueOf(v.getMarca().getIdMarca()));
        seleccionar(cbxTipo, String.valueOf(v.getTipo().getIdTipo()));
        seleccionar(cbxPropietario, v.getPropietario().getDni());
        txtModelo.setText(v.getModelo());
        txtAnio.setText(String.valueOf(v.getAnio()));
        seleccionar(cbxColor, v.getColor() == null ? null : v.getColor().name());
        txtNroMotor.setText(v.getNroMotor());
    }

    @Override
    protected void limpiarCampos() {
        txtPlaca.clear(); txtModelo.clear(); txtAnio.clear(); txtNroMotor.clear();
        cbxMarca.getSelectionModel().clearSelection();
        cbxTipo.getSelectionModel().clearSelection();
        cbxPropietario.getSelectionModel().clearSelection();
        cbxColor.getSelectionModel().clearSelection();
    }

    @Override protected void alEditar(Vehiculo v) { txtPlaca.setDisable(true); }   // la placa no se modifica
    @Override protected void alCancelar() { txtPlaca.setDisable(false); }

    @Override
    protected Map<String, Control> camposValidables() {
        Map<String, Control> m = new LinkedHashMap<>();
        m.put("placa", txtPlaca);
        m.put("marca", cbxMarca);
        m.put("tipo", cbxTipo);
        m.put("propietario", cbxPropietario);
        m.put("modelo", txtModelo);
        m.put("anio", txtAnio);
        m.put("color", cbxColor);
        m.put("nroMotor", txtNroMotor);
        return m;
    }

    @Override protected String idDe(Vehiculo v) { return v.getPlaca(); }

    @Override
    protected boolean coincideFiltro(Vehiculo v, String f) {
        return v.getPlaca().toLowerCase().contains(f)
                || v.getMarca().getNombre().toLowerCase().contains(f)
                || v.getTipo().getNombre().toLowerCase().contains(f)
                || v.getModelo().toLowerCase().contains(f)
                || v.getPropietario().getNombre().toLowerCase().contains(f);
    }

    @Override protected String descripcion(Vehiculo v) { return "el vehículo con placa " + v.getPlaca(); }
}
