package pe.edu.upeu.cochera.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.components.ColumnInfo;
import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.dto.SessionManager;
import pe.edu.upeu.cochera.model.Usuario;
import pe.edu.upeu.cochera.service.ICrudGenericoService;
import pe.edu.upeu.cochera.service.IPerfilService;
import pe.edu.upeu.cochera.service.IUsuarioService;

import java.util.LinkedHashMap;
import java.util.Map;

@RequiredArgsConstructor
public class UsuarioController extends BaseCrudController<Usuario, Long> {

    private final IUsuarioService us;
    private final IPerfilService ps;

    @FXML TextField txtUsuario;
    @FXML PasswordField txtClave;
    @FXML ComboBox<ComboBoxOption> cbxPerfil, cbxEstado;

    @Override
    protected void prepararFormulario() {
        cbxPerfil.getItems().addAll(ps.listarCombobox());
        cbxEstado.getItems().addAll(us.listarEstados());
        cbxEstado.getSelectionModel().selectFirst();
    }

    @Override protected ICrudGenericoService<Usuario, Long> servicio() { return us; }

    @Override
    protected LinkedHashMap<String, ColumnInfo> columnas() {
        LinkedHashMap<String, ColumnInfo> c = new LinkedHashMap<>();
        c.put("ID", new ColumnInfo("idUsuario", 50.0));
        c.put("Usuario", new ColumnInfo("usuario", 150.0));
        c.put("Perfil", new ColumnInfo("perfil.nombre", 140.0));
        c.put("Estado", new ColumnInfo("estado", 100.0));
        return c;
    }

    @Override
    protected Usuario leerFormulario() {
        return Usuario.builder()
                .idUsuario(enEdicion != null ? enEdicion.getIdUsuario() : null)
                .usuario(texto(txtUsuario))
                .clave(txtClave.getText() == null ? "" : txtClave.getText())
                .perfil(elegido(cbxPerfil, k -> ps.findById(Long.parseLong(k))))
                .estado(claveDe(cbxEstado))
                .build();
    }

    @Override
    protected void llenarFormulario(Usuario u) {
        txtUsuario.setText(u.getUsuario());
        txtClave.setText(u.getClave());
        seleccionar(cbxPerfil, String.valueOf(u.getPerfil().getIdPerfil()));
        seleccionar(cbxEstado, u.getEstado());
    }

    @Override
    protected void limpiarCampos() {
        txtUsuario.clear();
        txtClave.clear();
        cbxPerfil.getSelectionModel().clearSelection();
        cbxEstado.getSelectionModel().selectFirst();
    }

    @Override
    protected Map<String, Control> camposValidables() {
        Map<String, Control> m = new LinkedHashMap<>();
        m.put("usuario", txtUsuario);
        m.put("clave", txtClave);
        m.put("perfil", cbxPerfil);
        m.put("estado", cbxEstado);
        return m;
    }

    @Override
    protected String validarEliminacion(Usuario u) {
        Long actual = SessionManager.getInstance().getUserId();
        return u.getIdUsuario().equals(actual) ? "No puedes eliminar el usuario con el que iniciaste sesión" : null;
    }

    @Override protected Long idDe(Usuario u) { return u.getIdUsuario(); }

    @Override
    protected boolean coincideFiltro(Usuario u, String f) {
        return u.getUsuario().toLowerCase().contains(f) || u.getPerfil().getNombre().toLowerCase().contains(f);
    }

    @Override protected String descripcion(Usuario u) { return "al usuario " + u.getUsuario(); }
}
