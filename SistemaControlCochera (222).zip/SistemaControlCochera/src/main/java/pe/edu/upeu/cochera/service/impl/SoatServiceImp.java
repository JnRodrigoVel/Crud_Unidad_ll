package pe.edu.upeu.cochera.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.exception.RegistroDuplicadoException;
import pe.edu.upeu.cochera.model.Soat;
import pe.edu.upeu.cochera.repository.ICrudGenericoRepository;
import pe.edu.upeu.cochera.repository.SoatRepository;
import pe.edu.upeu.cochera.service.ISoatService;

@RequiredArgsConstructor
public class SoatServiceImp extends CrudGenericoServiceImp<Soat, Long> implements ISoatService {

    private final SoatRepository repo;

    @Override
    protected ICrudGenericoRepository<Soat, Long> getRepo() {
        return repo;
    }

    @Override
    public Soat save(Soat soat) {
        validarPoliza(null, soat);
        return super.save(soat);
    }

    @Override
    public Soat update(Long id, Soat soat) {
        validarPoliza(id, soat);
        return super.update(id, soat);
    }

    private void validarPoliza(Long idActual, Soat soat) {
        boolean repetida = repo.buscarPorPoliza(soat.getNroPoliza())
                .filter(otro -> !otro.getIdSoat().equals(idActual))
                .isPresent();
        if (repetida) {
            throw new RegistroDuplicadoException("Ya existe un SOAT con la póliza " + soat.getNroPoliza());
        }
    }
}
