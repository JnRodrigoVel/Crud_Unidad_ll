package pe.edu.upeu.cochera.repository;

import pe.edu.upeu.cochera.enums.ColorVehiculo;
import pe.edu.upeu.cochera.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class VehiculoRepository extends AbstractJpaRepository<Vehiculo, String> {

    private static final String SELECT_JOIN =
            "SELECT v.*, m.nombre AS marca_nombre, t.nombre AS tipo_nombre, p.nombre AS prop_nombre " +
                    "FROM vehiculo v " +
                    "JOIN marca m ON v.id_marca = m.id_marca " +
                    "JOIN tipo_vehiculo t ON v.id_tipo = t.id_tipo " +
                    "JOIN propietario p ON v.dni = p.dni ";

    @Override protected String getTableName() { return "vehiculo"; }
    @Override protected String getPkColumn() { return "placa"; }

    @Override
    public List<Vehiculo> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY v.placa");
    }

    @Override
    public Optional<Vehiculo> findById(String placa) {
        return executeQueryOne(SELECT_JOIN + "WHERE v.placa = ?", placa);
    }

    @Override
    protected Vehiculo mapRow(ResultSet rs) throws SQLException {
        String color = rs.getString("color");
        return Vehiculo.builder()
                .placa(rs.getString("placa"))
                .marca(Marca.builder()
                        .idMarca(rs.getLong("id_marca"))
                        .nombre(rs.getString("marca_nombre")).build())
                .tipo(TipoVehiculo.builder()
                        .idTipo(rs.getLong("id_tipo"))
                        .nombre(rs.getString("tipo_nombre")).build())
                .propietario(Propietario.builder()
                        .dni(rs.getString("dni"))
                        .nombre(rs.getString("prop_nombre")).build())
                .modelo(rs.getString("modelo"))
                .anio(rs.getInt("anio"))
                .color(color == null ? null : ColorVehiculo.valueOf(color))
                .nroMotor(rs.getString("nro_motor"))
                .build();
    }

    @Override
    protected Vehiculo insert(Connection conn, Vehiculo e) throws SQLException {
        executeUpdate(conn,
                "INSERT INTO vehiculo(placa,id_marca,id_tipo,dni,modelo,anio,color,nro_motor) VALUES(?,?,?,?,?,?,?,?)",
                e.getPlaca(), e.getMarca().getIdMarca(), e.getTipo().getIdTipo(),
                e.getPropietario().getDni(), e.getModelo(), e.getAnio(),
                e.getColor().name(), e.getNroMotor());
        return e;
    }

    @Override
    protected Vehiculo updateRow(Connection conn, Vehiculo e) throws SQLException {
        executeUpdate(conn,
                "UPDATE vehiculo SET id_marca=?,id_tipo=?,dni=?,modelo=?,anio=?,color=?,nro_motor=? WHERE placa=?",
                e.getMarca().getIdMarca(), e.getTipo().getIdTipo(), e.getPropietario().getDni(),
                e.getModelo(), e.getAnio(), e.getColor().name(), e.getNroMotor(), e.getPlaca());
        return e;
    }
}
