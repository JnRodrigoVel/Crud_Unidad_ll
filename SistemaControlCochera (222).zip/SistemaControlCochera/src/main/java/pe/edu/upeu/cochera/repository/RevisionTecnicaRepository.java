package pe.edu.upeu.cochera.repository;

import pe.edu.upeu.cochera.enums.ResultadoRevision;
import pe.edu.upeu.cochera.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class RevisionTecnicaRepository extends AbstractJpaRepository<RevisionTecnica, Long> {

    private static final String SELECT_JOIN =
            "SELECT r.*, v.modelo AS veh_modelo FROM revision_tecnica r " +
                    "JOIN vehiculo v ON r.placa = v.placa ";

    @Override protected String getTableName() { return "revision_tecnica"; }
    @Override protected String getPkColumn() { return "id_revision"; }

    @Override
    public List<RevisionTecnica> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY r.fecha_vencimiento");
    }

    @Override
    public Optional<RevisionTecnica> findById(Long id) {
        return executeQueryOne(SELECT_JOIN + "WHERE r.id_revision = ?", id);
    }

    public Optional<RevisionTecnica> buscarPorCertificado(String nroCertificado) {
        return executeQueryOne(SELECT_JOIN + "WHERE r.nro_certificado = ?", nroCertificado);
    }

    @Override
    protected RevisionTecnica mapRow(ResultSet rs) throws SQLException {
        String resultado = rs.getString("resultado");
        return RevisionTecnica.builder()
                .idRevision(rs.getLong("id_revision"))
                .vehiculo(Vehiculo.builder()
                        .placa(rs.getString("placa"))
                        .modelo(rs.getString("veh_modelo")).build())
                .nroCertificado(rs.getString("nro_certificado"))
                .fechaRevision(getFecha(rs, "fecha_revision"))
                .fechaVencimiento(getFecha(rs, "fecha_vencimiento"))
                .resultado(resultado == null ? null : ResultadoRevision.valueOf(resultado))
                .build();
    }

    @Override
    protected RevisionTecnica insert(Connection conn, RevisionTecnica e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO revision_tecnica(placa,nro_certificado,fecha_revision,fecha_vencimiento,resultado) VALUES(?,?,?,?,?)",
                e.getVehiculo().getPlaca(), e.getNroCertificado(), e.getFechaRevision(),
                e.getFechaVencimiento(), e.getResultado().name());
        e.setIdRevision(id);
        return e;
    }

    @Override
    protected RevisionTecnica updateRow(Connection conn, RevisionTecnica e) throws SQLException {
        executeUpdate(conn,
                "UPDATE revision_tecnica SET placa=?,nro_certificado=?,fecha_revision=?,fecha_vencimiento=?,resultado=? WHERE id_revision=?",
                e.getVehiculo().getPlaca(), e.getNroCertificado(), e.getFechaRevision(),
                e.getFechaVencimiento(), e.getResultado().name(), e.getIdRevision());
        return e;
    }
}
