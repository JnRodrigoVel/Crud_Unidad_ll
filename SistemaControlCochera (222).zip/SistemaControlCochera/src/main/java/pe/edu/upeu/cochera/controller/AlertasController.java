package pe.edu.upeu.cochera.controller;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.dto.AlertaVencimiento;
import pe.edu.upeu.cochera.enums.EstadoVigencia;
import pe.edu.upeu.cochera.model.RevisionTecnica;
import pe.edu.upeu.cochera.model.Soat;
import pe.edu.upeu.cochera.service.IRevisionTecnicaService;
import pe.edu.upeu.cochera.service.ISoatService;
import pe.edu.upeu.cochera.utils.FechaUtil;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Pantalla de inicio: SOAT y revisiones técnicas vencidos o por vencer. */
@RequiredArgsConstructor
public class AlertasController {

    private final ISoatService soatService;
    private final IRevisionTecnicaService revisionService;

    @FXML private TableView<AlertaVencimiento> tableView;
    @FXML private Label lblResumen;

    @FXML
    public void initialize() {
        tableView.getColumns().clear();
        agregarColumna("Placa", "placa", 110);
        agregarColumna("Documento", "documento", 160);
        agregarColumna("N° documento", "numero", 160);
        agregarColumna("Vence", "fechaVencimiento", 110);
        agregarColumna("Días restantes", "diasRestantes", 120);
        agregarColumna("Estado", "estado", 120);
        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        actualizar();
    }

    @FXML
    public void actualizar() {
        List<AlertaVencimiento> alertas = new ArrayList<>();
        try {
            for (Soat s : soatService.findAll()) {
                agregar(alertas, s.getVehiculo().getPlaca(), "SOAT", s.getNroPoliza(), s.getFechaVencimiento());
            }
            for (RevisionTecnica r : revisionService.findAll()) {
                agregar(alertas, r.getVehiculo().getPlaca(), "Revisión técnica", r.getNroCertificado(),
                        r.getFechaVencimiento());
            }
        } catch (RuntimeException e) {
            lblResumen.setText("No se pudieron cargar las alertas: " + e.getMessage());
            return;
        }
        alertas.sort(Comparator.comparing(AlertaVencimiento::getDiasRestantes,
                Comparator.nullsFirst(Comparator.naturalOrder())));
        tableView.setItems(FXCollections.observableArrayList(alertas));

        long vencidos = alertas.stream()
                .filter(a -> a.getEstado().equals(EstadoVigencia.VENCIDO.getDescripcion())).count();
        lblResumen.setText(alertas.isEmpty()
                ? "Todos los documentos están vigentes."
                : vencidos + " vencido(s) y " + (alertas.size() - vencidos)
                + " por vencer en los próximos " + EstadoVigencia.DIAS_AVISO + " días.");
    }

    private void agregar(List<AlertaVencimiento> lista, String placa, String documento,
                         String numero, LocalDate vencimiento) {
        EstadoVigencia estado = EstadoVigencia.de(vencimiento);
        if (estado == EstadoVigencia.VIGENTE) return;
        lista.add(new AlertaVencimiento(placa, documento, numero,
                FechaUtil.formatear(vencimiento),
                EstadoVigencia.diasRestantes(vencimiento), estado.getDescripcion()));
    }

    private void agregarColumna(String titulo, String campo, double ancho) {
        TableColumn<AlertaVencimiento, Object> col = new TableColumn<>(titulo);
        col.setCellValueFactory(new PropertyValueFactory<>(campo));
        col.setPrefWidth(ancho);
        tableView.getColumns().add(col);
    }
}
