package pe.edu.upeu.cochera.service;

import pe.edu.upeu.cochera.model.Transferencia;

public interface ITransferenciaService extends ICrudGenericoService<Transferencia, Long> {
}
