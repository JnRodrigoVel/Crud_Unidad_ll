package pe.edu.upeu.cochera.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import pe.edu.upeu.cochera.components.ColumnInfo;
import pe.edu.upeu.cochera.components.TableViewHelper;
import pe.edu.upeu.cochera.components.Toast;
import pe.edu.upeu.cochera.components.ToltipCustom;
import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.exception.RegistroDuplicadoException;
import pe.edu.upeu.cochera.exception.ReglaNegocioException;
import pe.edu.upeu.cochera.service.ICrudGenericoService;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.*;
import java.util.function.Function;

/**
 * Lógica común de todas las pantallas CRUD (misma idea que VehiculoController del
 * padrón original: formulario + tabla con buscador, validación con Jakarta y Toast).
 * Cada pantalla solo indica sus campos, sus columnas y cómo armar la entidad.
 */
public abstract class BaseCrudController<T, ID> {

    @FXML protected TableView<T> tableView;
    @FXML protected TextField txtFiltroDato;
    @FXML protected Button btnGuardar;
    @FXML protected Label lbnMsg;
    @FXML protected AnchorPane miContenedor;

    private static final Validator VALIDATOR =
            Validation.buildDefaultValidatorFactory().getValidator();

    protected final ToltipCustom ttc = new ToltipCustom();

    /** Registro que se está editando (null = registro nuevo). */
    protected T enEdicion;

    private ObservableList<T> datos;
    private FilteredList<T> filtrada;

    // ---------- lo que cada pantalla debe indicar ----------
    protected abstract ICrudGenericoService<T, ID> servicio();
    protected abstract LinkedHashMap<String, ColumnInfo> columnas();
    protected abstract T leerFormulario();
    protected abstract void llenarFormulario(T entidad);
    protected abstract void limpiarCampos();
    /** propiedad validada (nombre del atributo del modelo) → control donde se marca el error. */
    protected abstract Map<String, Control> camposValidables();
    protected abstract ID idDe(T entidad);
    protected abstract boolean coincideFiltro(T entidad, String filtroEnMinuscula);
    protected abstract String descripcion(T entidad);

    // ---------- ganchos opcionales ----------
    protected void prepararFormulario() { }
    protected void alEditar(T entidad) { }
    protected void alCancelar() { }
    protected String validarEliminacion(T entidad) { return null; }

    @FXML
    public void initialize() {
        enEdicion = null;
        prepararFormulario();

        new TableViewHelper<T>().addColumnsInOrderWithSize(tableView, columnas(), this::editar, this::eliminar);
        tableView.setTableMenuButtonVisible(true);

        datos = FXCollections.observableArrayList();
        filtrada = new FilteredList<>(datos, t -> true);
        SortedList<T> ordenada = new SortedList<>(filtrada);
        ordenada.comparatorProperty().bind(tableView.comparatorProperty());
        tableView.setItems(ordenada);
        txtFiltroDato.textProperty().addListener((obs, o, n) -> filtrar(n));

        lbnMsg.setText("");
        listar();
    }

    protected void listar() {
        try {
            datos.setAll(servicio().findAll());
        } catch (Exception e) {
            mostrarError("No se pudo cargar la lista: " + mensajeAmigable(e));
        }
    }

    private void filtrar(String texto) {
        String f = texto == null ? "" : texto.trim().toLowerCase();
        filtrada.setPredicate(t -> f.isEmpty() || coincideFiltro(t, f));
    }

    // ---------- botones del formulario ----------
    @FXML
    public void guardar() {
        limpiarErrores();
        T entidad = leerFormulario();

        List<ConstraintViolation<T>> violaciones = VALIDATOR.validate(entidad).stream()
                .sorted(Comparator.comparing(v -> v.getPropertyPath().toString()))
                .toList();
        if (!violaciones.isEmpty()) {
            mostrarErroresValidacion(violaciones);
            return;
        }

        try {
            if (enEdicion != null) {
                servicio().update(idDe(enEdicion), entidad);
                toast("Se actualizó correctamente!!");
            } else {
                servicio().save(entidad);
                toast("Se guardó correctamente!!");
            }
            cancelar();
            listar();
        } catch (RegistroDuplicadoException | ReglaNegocioException e) {
            mostrarError(e.getMessage());
        } catch (RuntimeException e) {
            mostrarError("No se pudo guardar: " + mensajeAmigable(e));
        }
    }

    @FXML
    public void cancelar() {
        limpiarCampos();
        enEdicion = null;
        alCancelar();
        btnGuardar.setText("Guardar");
        tableView.getSelectionModel().clearSelection();
        lbnMsg.setText("");
        limpiarErrores();
    }

    protected void editar(T entidad) {
        limpiarErrores();
        enEdicion = entidad;
        llenarFormulario(entidad);
        alEditar(entidad);
        btnGuardar.setText("Actualizar");
        lbnMsg.setText("");
    }

    protected void eliminar(T entidad) {
        String motivo = validarEliminacion(entidad);
        if (motivo != null) {
            mostrarError(motivo);
            return;
        }
        Alert confirmacion = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Eliminar " + descripcion(entidad) + "?", ButtonType.YES, ButtonType.NO);
        confirmacion.setTitle("Confirmar eliminación");
        confirmacion.setHeaderText(null);
        Optional<ButtonType> respuesta = confirmacion.showAndWait();
        if (respuesta.isPresent() && respuesta.get() == ButtonType.YES) {
            try {
                servicio().delete(idDe(entidad));
                if (enEdicion != null && Objects.equals(idDe(enEdicion), idDe(entidad))) cancelar();
                toast("Se eliminó correctamente!!");
                listar();
            } catch (RuntimeException e) {
                mostrarError("No se pudo eliminar: " + mensajeAmigable(e));
            }
        }
    }

    // ---------- errores y mensajes ----------
    private void mostrarErroresValidacion(List<ConstraintViolation<T>> violaciones) {
        String primerMensaje = null;
        Control primerControl = null;
        for (Map.Entry<String, Control> campo : camposValidables().entrySet()) {
            for (ConstraintViolation<T> v : violaciones) {
                if (v.getPropertyPath().toString().equals(campo.getKey())) {
                    ttc.marcarError(campo.getValue(), v.getMessage().trim());
                    if (primerMensaje == null) {
                        primerMensaje = v.getMessage();
                        primerControl = campo.getValue();
                    }
                    break;
                }
            }
        }
        if (primerMensaje == null) primerMensaje = violaciones.get(0).getMessage();
        mostrarError(primerMensaje);
        if (primerControl != null) {
            Control foco = primerControl;
            Platform.runLater(foco::requestFocus);
        }
    }

    protected void mostrarError(String mensaje) {
        lbnMsg.setText(mensaje);
        lbnMsg.setStyle("-fx-text-fill: red; -fx-font-size: 14px;");
    }

    protected void limpiarErrores() {
        camposValidables().values().forEach(ttc::limpiarCampo);
    }

    protected void toast(String mensaje) {
        Stage stage = (Stage) miContenedor.getScene().getWindow();
        Toast.showToast(stage, mensaje, 2000, stage.getWidth() / 1.5, stage.getHeight() / 2);
    }

    /** Traduce los errores de la base de datos a un texto entendible. */
    protected String mensajeAmigable(Throwable e) {
        for (Throwable t = e; t != null; t = t.getCause()) {
            if (t instanceof SQLException sql) {
                if ("23503".equals(sql.getSQLState())) {
                    return "el registro está relacionado con otros datos (vehículos, documentos, etc.).";
                }
                if ("23505".equals(sql.getSQLState())) {
                    return "ya existe un registro con esos datos.";
                }
            }
        }
        return e.getMessage();
    }

    // ---------- utilidades para leer/llenar controles ----------
    /** Solo acepta dígitos, hasta la cantidad indicada. */
    protected TextFormatter<String> soloDigitos(int max) {
        return new TextFormatter<>(c -> c.getControlNewText().matches("\\d{0," + max + "}") ? c : null);
    }

    /** Convierte a mayúsculas lo que se escribe. */
    protected TextFormatter<String> mayusculas() {
        return new TextFormatter<>(c -> {
            c.setText(c.getText().toUpperCase());
            return c;
        });
    }

    protected String texto(TextInputControl campo) {
        return campo.getText() == null ? "" : campo.getText().trim();
    }

    protected Integer entero(TextInputControl campo) {
        String t = texto(campo);
        if (t.isEmpty()) return null;
        try {
            return Integer.parseInt(t);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    protected LocalDate fecha(DatePicker dp) {
        return dp.getValue();
    }

    protected String claveDe(ComboBox<ComboBoxOption> cbx) {
        ComboBoxOption op = cbx.getSelectionModel().getSelectedItem();
        return op == null ? null : op.getKey();
    }

    /** Busca la entidad elegida en el combo (null si no se eligió nada). */
    protected <E> E elegido(ComboBox<ComboBoxOption> cbx, Function<String, E> buscar) {
        String clave = claveDe(cbx);
        return clave == null ? null : buscar.apply(clave);
    }

    protected void seleccionar(ComboBox<ComboBoxOption> cbx, String clave) {
        cbx.getSelectionModel().select(cbx.getItems().stream()
                .filter(o -> o.getKey().equals(clave))
                .findFirst().orElse(null));
    }
}
