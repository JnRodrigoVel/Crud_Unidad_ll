package pe.edu.upeu.cochera.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.components.ColumnInfo;
import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.components.ComboBoxAutoComplete;
import pe.edu.upeu.cochera.model.TarjetaPropiedad;
import pe.edu.upeu.cochera.model.Vehiculo;
import pe.edu.upeu.cochera.service.ICrudGenericoService;
import pe.edu.upeu.cochera.service.ITarjetaPropiedadService;
import pe.edu.upeu.cochera.service.IVehiculoService;
import pe.edu.upeu.cochera.utils.FechaUtil;

import java.util.LinkedHashMap;
import java.util.Map;

@RequiredArgsConstructor
public class TarjetaPropiedadController extends BaseCrudController<TarjetaPropiedad, Long> {

    private final ITarjetaPropiedadService tps;
    private final IVehiculoService vs;

    @FXML ComboBox<ComboBoxOption> cbxVehiculo;
    @FXML TextField txtNroTarjeta;
    @FXML DatePicker dpFechaEmision;

    @Override
    protected void prepararFormulario() {
        cbxVehiculo.getItems().addAll(vs.listarCombobox());
        new ComboBoxAutoComplete<>(cbxVehiculo);
        FechaUtil.configurar(dpFechaEmision);
        txtNroTarjeta.setTextFormatter(mayusculas());
    }

    @Override protected ICrudGenericoService<TarjetaPropiedad, Long> servicio() { return tps; }

    @Override
    protected LinkedHashMap<String, ColumnInfo> columnas() {
        LinkedHashMap<String, ColumnInfo> c = new LinkedHashMap<>();
        c.put("ID", new ColumnInfo("idTarjeta", 60.0));
        c.put("Placa", new ColumnInfo("vehiculo.placa", 110.0));
        c.put("N° Tarjeta", new ColumnInfo("nroTarjeta", 150.0));
        c.put("Fecha de emisión", new ColumnInfo("fechaEmisionTxt", 130.0));
        return c;
    }

    @Override
    protected TarjetaPropiedad leerFormulario() {
        return TarjetaPropiedad.builder()
                .idTarjeta(enEdicion != null ? enEdicion.getIdTarjeta() : null)
                .vehiculo(elegido(cbxVehiculo, placa -> Vehiculo.builder().placa(placa).build()))
                .nroTarjeta(texto(txtNroTarjeta))
                .fechaEmision(fecha(dpFechaEmision))
                .build();
    }

    @Override
    protected void llenarFormulario(TarjetaPropiedad t) {
        seleccionar(cbxVehiculo, t.getVehiculo().getPlaca());
        txtNroTarjeta.setText(t.getNroTarjeta());
        dpFechaEmision.setValue(t.getFechaEmision());
    }

    @Override
    protected void limpiarCampos() {
        cbxVehiculo.getSelectionModel().clearSelection();
        txtNroTarjeta.clear();
        dpFechaEmision.setValue(null);
    }

    @Override
    protected Map<String, Control> camposValidables() {
        Map<String, Control> m = new LinkedHashMap<>();
        m.put("vehiculo", cbxVehiculo);
        m.put("nroTarjeta", txtNroTarjeta);
        m.put("fechaEmision", dpFechaEmision);
        return m;
    }

    @Override protected Long idDe(TarjetaPropiedad t) { return t.getIdTarjeta(); }

    @Override
    protected boolean coincideFiltro(TarjetaPropiedad t, String f) {
        return t.getVehiculo().getPlaca().toLowerCase().contains(f)
                || t.getNroTarjeta().toLowerCase().contains(f);
    }

    @Override
    protected String descripcion(TarjetaPropiedad t) {
        return "la tarjeta " + t.getNroTarjeta() + " del vehículo " + t.getVehiculo().getPlaca();
    }
}
