package pe.edu.upeu.cochera.config;

import pe.edu.upeu.cochera.controller.*;
import pe.edu.upeu.cochera.repository.*;
import pe.edu.upeu.cochera.service.*;
import pe.edu.upeu.cochera.service.impl.*;

import java.util.HashMap;
import java.util.Map;

public class AppContext {

    // Singleton: una sola instancia en toda la app
    private static AppContext instance;

    public static synchronized AppContext getInstance() {
        if (instance == null) instance = new AppContext();
        return instance;
    }

    // El "directorio": Clase → Objeto
    private final Map<Class<?>, Object> contenedor = new HashMap<>();

    private AppContext() {
        registrarRepositorios();
        registrarServicios();
        registrarControladores();
    }

    // CAPA 1 — REPOSITORIOS (cada uno habla con una tabla)
    private void registrarRepositorios() {
        registrar(PerfilRepository.class, new PerfilRepository());
        registrar(UsuarioRepository.class, new UsuarioRepository());
        registrar(PropietarioRepository.class, new PropietarioRepository());
        registrar(MarcaRepository.class, new MarcaRepository());
        registrar(TipoVehiculoRepository.class, new TipoVehiculoRepository());
        registrar(VehiculoRepository.class, new VehiculoRepository());
        registrar(TarjetaPropiedadRepository.class, new TarjetaPropiedadRepository());
        registrar(SoatRepository.class, new SoatRepository());
        registrar(RevisionTecnicaRepository.class, new RevisionTecnicaRepository());
        registrar(TransferenciaRepository.class, new TransferenciaRepository());
    }

    // CAPA 2 — SERVICIOS (reciben su repositorio por constructor)
    private void registrarServicios() {
        registrar(IPerfilService.class, new PerfilServiceImp(getBean(PerfilRepository.class)));
        registrar(IUsuarioService.class, new UsuarioServiceImp(getBean(UsuarioRepository.class)));
        registrar(IPropietarioService.class, new PropietarioServiceImp(getBean(PropietarioRepository.class)));
        registrar(IMarcaService.class, new MarcaServiceImp(getBean(MarcaRepository.class)));
        registrar(ITipoVehiculoService.class, new TipoVehiculoServiceImp(getBean(TipoVehiculoRepository.class)));
        registrar(IVehiculoService.class, new VehiculoServiceImp(getBean(VehiculoRepository.class)));
        registrar(ITarjetaPropiedadService.class, new TarjetaPropiedadServiceImp(getBean(TarjetaPropiedadRepository.class)));
        registrar(ISoatService.class, new SoatServiceImp(getBean(SoatRepository.class)));
        registrar(IRevisionTecnicaService.class, new RevisionTecnicaServiceImp(getBean(RevisionTecnicaRepository.class)));
        registrar(ITransferenciaService.class, new TransferenciaServiceImp(
                getBean(TransferenciaRepository.class), getBean(VehiculoRepository.class)));
        registrar(IMenuMenuItemDao.class, new MenuMenuItemDaoImp());
    }

    // CAPA 3 — CONTROLADORES JavaFX (el FXMLLoader los busca aquí con setControllerFactory)
    private void registrarControladores() {
        registrar(LoginController.class, new LoginController(getBean(IUsuarioService.class)));
        registrar(MainGuiController.class, new MainGuiController(getBean(IMenuMenuItemDao.class)));
        registrar(AlertasController.class, new AlertasController(
                getBean(ISoatService.class), getBean(IRevisionTecnicaService.class)));
        registrar(PropietarioController.class, new PropietarioController(getBean(IPropietarioService.class)));
        registrar(MarcaController.class, new MarcaController(getBean(IMarcaService.class)));
        registrar(TipoVehiculoController.class, new TipoVehiculoController(getBean(ITipoVehiculoService.class)));
        registrar(VehiculoController.class, new VehiculoController(
                getBean(IVehiculoService.class), getBean(IMarcaService.class),
                getBean(ITipoVehiculoService.class), getBean(IPropietarioService.class)));
        registrar(TarjetaPropiedadController.class, new TarjetaPropiedadController(
                getBean(ITarjetaPropiedadService.class), getBean(IVehiculoService.class)));
        registrar(SoatController.class, new SoatController(
                getBean(ISoatService.class), getBean(IVehiculoService.class)));
        registrar(RevisionTecnicaController.class, new RevisionTecnicaController(
                getBean(IRevisionTecnicaService.class), getBean(IVehiculoService.class)));
        registrar(TransferenciaController.class, new TransferenciaController(
                getBean(ITransferenciaService.class), getBean(IVehiculoService.class),
                getBean(IPropietarioService.class), getBean(IUsuarioService.class)));
        registrar(UsuarioController.class, new UsuarioController(
                getBean(IUsuarioService.class), getBean(IPerfilService.class)));
    }

    private void registrar(Class<?> tipo, Object bean) {
        contenedor.put(tipo, bean);
    }

    @SuppressWarnings("unchecked")
    public <T> T getBean(Class<T> tipo) {
        Object bean = contenedor.get(tipo);
        if (bean == null) {
            // Si piden una interfaz, devuelve la implementación registrada
            bean = contenedor.values().stream()
                    .filter(b -> tipo.isAssignableFrom(b.getClass()))
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException(
                            "Bean no encontrado: " + tipo.getName() +
                                    "\n→ ¿Lo registraste en AppContext?"));
        }
        return (T) bean;
    }
}
