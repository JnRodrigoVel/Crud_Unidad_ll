package pe.edu.upeu.cochera.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.SistemaCochera;
import pe.edu.upeu.cochera.config.AppContext;
import pe.edu.upeu.cochera.dto.MenuMenuItenTO;
import pe.edu.upeu.cochera.dto.SessionManager;
import pe.edu.upeu.cochera.service.IMenuMenuItemDao;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RequiredArgsConstructor
public class MainGuiController {

    @FXML
    BorderPane bp;

    @FXML
    TabPane tabPane;

    @FXML
    Label lblSesion;

    private final IMenuMenuItemDao mmiDao;
    private Map<String, String[]> menuConfig;

    @FXML
    public void initialize() {
        SessionManager sesion = SessionManager.getInstance();
        lblSesion.setText("Usuario: " + sesion.getUserName() + "     |     Perfil: " + sesion.getUserPerfil());

        List<MenuMenuItenTO> accesos = mmiDao.listaAccesos(sesion.getUserPerfil());
        menuConfig = mmiDao.accesosAutorizados(accesos);
        bp.setTop(construirMenu(accesos));
        bp.setCenter(tabPane);

        // pantalla de inicio: alertas de vencimiento
        abrirTabPaneFXML("/view/main_alertas.fxml", "Alertas de vencimiento");
    }

    private MenuBar construirMenu(List<MenuMenuItenTO> accesos) {
        Map<String, Menu> menus = new LinkedHashMap<>();
        for (MenuMenuItenTO a : accesos) {
            Menu menu = menus.computeIfAbsent(a.getMenunombre(), Menu::new);
            MenuItem item = new MenuItem(a.getMenuitemnombre());
            item.setId("mi" + a.getIdNombreObj().substring(2));
            item.setOnAction(this::alSeleccionarOpcion);
            menu.getItems().add(item);
        }
        MenuBar menuBar = new MenuBar();
        menuBar.getMenus().addAll(menus.values());
        return menuBar;
    }

    private void alSeleccionarOpcion(ActionEvent e) {
        String id = ((MenuItem) e.getSource()).getId();
        String[] cfg = menuConfig.get(id);
        if (cfg == null) return;
        if (cfg[2].equals("C")) {
            cerrarSesion();
        } else {
            abrirTabPaneFXML(cfg[0], cfg[1]);
        }
    }

    private void abrirTabPaneFXML(String fxmlPath, String titulo) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlPath));
            fxmlLoader.setControllerFactory(AppContext.getInstance()::getBean);
            Parent root = fxmlLoader.load();

            ScrollPane scrollPane = new ScrollPane(root);
            scrollPane.setFitToWidth(true);
            scrollPane.setFitToHeight(true);
            tabPane.getTabs().clear();
            tabPane.getTabs().add(new Tab(titulo, scrollPane));
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    private void cerrarSesion() {
        SessionManager sesion = SessionManager.getInstance();
        sesion.setUserId(null);
        sesion.setUserName(null);
        sesion.setUserPerfil(null);
        try {
            Stage stage = (Stage) bp.getScene().getWindow();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/login.fxml"));
            fxmlLoader.setControllerFactory(AppContext.getInstance()::getBean);
            Scene scene = new Scene(fxmlLoader.load());
            scene.getStylesheets().add(SistemaCochera.class.getResource("/css/style.css").toExternalForm());
            stage.setScene(scene);
            stage.setResizable(false);
            stage.sizeToScene();
            stage.centerOnScreen();
            stage.setTitle("Sistema de Control Cochera");
            stage.show();
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }
}
