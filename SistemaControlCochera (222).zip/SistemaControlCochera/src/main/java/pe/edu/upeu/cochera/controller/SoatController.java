package pe.edu.upeu.cochera.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.components.ColumnInfo;
import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.components.ComboBoxAutoComplete;
import pe.edu.upeu.cochera.model.Soat;
import pe.edu.upeu.cochera.model.Vehiculo;
import pe.edu.upeu.cochera.service.ICrudGenericoService;
import pe.edu.upeu.cochera.service.ISoatService;
import pe.edu.upeu.cochera.service.IVehiculoService;
import pe.edu.upeu.cochera.utils.FechaUtil;

import java.util.LinkedHashMap;
import java.util.Map;

@RequiredArgsConstructor
public class SoatController extends BaseCrudController<Soat, Long> {

    private final ISoatService ss;
    private final IVehiculoService vs;

    @FXML ComboBox<ComboBoxOption> cbxVehiculo;
    @FXML TextField txtNroPoliza, txtAseguradora;
    @FXML DatePicker dpFechaInicio, dpFechaVencimiento;

    @Override
    protected void prepararFormulario() {
        cbxVehiculo.getItems().addAll(vs.listarCombobox());
        new ComboBoxAutoComplete<>(cbxVehiculo);
        FechaUtil.configurar(dpFechaInicio);
        FechaUtil.configurar(dpFechaVencimiento);
        txtNroPoliza.setTextFormatter(mayusculas());
        // sugerencia: el SOAT dura un año (se puede cambiar)
        dpFechaInicio.valueProperty().addListener((obs, anterior, nueva) -> {
            if (nueva != null && dpFechaVencimiento.getValue() == null) {
                dpFechaVencimiento.setValue(nueva.plusYears(1));
            }
        });
    }

    @Override protected ICrudGenericoService<Soat, Long> servicio() { return ss; }

    @Override
    protected LinkedHashMap<String, ColumnInfo> columnas() {
        LinkedHashMap<String, ColumnInfo> c = new LinkedHashMap<>();
        c.put("ID", new ColumnInfo("idSoat", 50.0));
        c.put("Placa", new ColumnInfo("vehiculo.placa", 100.0));
        c.put("N° Póliza", new ColumnInfo("nroPoliza", 120.0));
        c.put("Aseguradora", new ColumnInfo("aseguradora", 150.0));
        c.put("Inicio", new ColumnInfo("fechaInicioTxt", 100.0));
        c.put("Vence", new ColumnInfo("fechaVencimientoTxt", 100.0));
        c.put("Días", new ColumnInfo("diasRestantes", 60.0));
        c.put("Estado", new ColumnInfo("estado", 90.0));
        return c;
    }

    @Override
    protected Soat leerFormulario() {
        return Soat.builder()
                .idSoat(enEdicion != null ? enEdicion.getIdSoat() : null)
                .vehiculo(elegido(cbxVehiculo, placa -> Vehiculo.builder().placa(placa).build()))
                .nroPoliza(texto(txtNroPoliza))
                .aseguradora(texto(txtAseguradora))
                .fechaInicio(fecha(dpFechaInicio))
                .fechaVencimiento(fecha(dpFechaVencimiento))
                .build();
    }

    @Override
    protected void llenarFormulario(Soat s) {
        seleccionar(cbxVehiculo, s.getVehiculo().getPlaca());
        txtNroPoliza.setText(s.getNroPoliza());
        txtAseguradora.setText(s.getAseguradora());
        dpFechaVencimiento.setValue(s.getFechaVencimiento());
        dpFechaInicio.setValue(s.getFechaInicio());
    }

    @Override
    protected void limpiarCampos() {
        cbxVehiculo.getSelectionModel().clearSelection();
        txtNroPoliza.clear();
        txtAseguradora.clear();
        dpFechaInicio.setValue(null);
        dpFechaVencimiento.setValue(null);
    }

    @Override
    protected Map<String, Control> camposValidables() {
        Map<String, Control> m = new LinkedHashMap<>();
        m.put("vehiculo", cbxVehiculo);
        m.put("nroPoliza", txtNroPoliza);
        m.put("aseguradora", txtAseguradora);
        m.put("fechaInicio", dpFechaInicio);
        m.put("fechaVencimiento", dpFechaVencimiento);
        m.put("vigenciaValida", dpFechaVencimiento);
        return m;
    }

    @Override protected Long idDe(Soat s) { return s.getIdSoat(); }

    @Override
    protected boolean coincideFiltro(Soat s, String f) {
        return s.getVehiculo().getPlaca().toLowerCase().contains(f)
                || s.getNroPoliza().toLowerCase().contains(f)
                || s.getAseguradora().toLowerCase().contains(f)
                || s.getEstado().toLowerCase().contains(f);
    }

    @Override
    protected String descripcion(Soat s) {
        return "el SOAT " + s.getNroPoliza() + " del vehículo " + s.getVehiculo().getPlaca();
    }
}
