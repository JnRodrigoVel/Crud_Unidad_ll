package pe.edu.upeu.cochera.utils;

import javafx.scene.control.DatePicker;
import javafx.util.StringConverter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public final class FechaUtil {

    public static final DateTimeFormatter FORMATO = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private FechaUtil() {
    }

    public static String formatear(LocalDate fecha) {
        return fecha == null ? "" : FORMATO.format(fecha);
    }

    /** DatePicker que muestra y acepta fechas con formato dd/MM/yyyy. */
    public static void configurar(DatePicker dp) {
        dp.setPromptText("dd/mm/aaaa");
        dp.setConverter(new StringConverter<>() {
            @Override
            public String toString(LocalDate fecha) {
                return formatear(fecha);
            }

            @Override
            public LocalDate fromString(String texto) {
                if (texto == null || texto.isBlank()) return null;
                try {
                    return LocalDate.parse(texto.trim(), FORMATO);
                } catch (DateTimeParseException e) {
                    return null;
                }
            }
        });
    }
}
