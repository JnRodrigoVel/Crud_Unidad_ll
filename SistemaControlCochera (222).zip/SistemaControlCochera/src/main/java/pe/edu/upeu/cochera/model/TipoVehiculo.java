package pe.edu.upeu.cochera.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TipoVehiculo {
    private Long idTipo;
    @NotBlank(message = "El nombre del tipo es obligatorio")
    @Size(max = 30, message = "El nombre admite máximo 30 caracteres")
    private String nombre;
}
