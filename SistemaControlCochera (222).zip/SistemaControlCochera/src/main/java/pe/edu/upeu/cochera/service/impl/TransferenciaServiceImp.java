package pe.edu.upeu.cochera.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.exception.ModelNotFoundException;
import pe.edu.upeu.cochera.exception.ReglaNegocioException;
import pe.edu.upeu.cochera.model.Transferencia;
import pe.edu.upeu.cochera.model.Vehiculo;
import pe.edu.upeu.cochera.repository.ICrudGenericoRepository;
import pe.edu.upeu.cochera.repository.TransferenciaRepository;
import pe.edu.upeu.cochera.repository.VehiculoRepository;
import pe.edu.upeu.cochera.service.ITransferenciaService;

@RequiredArgsConstructor
public class TransferenciaServiceImp extends CrudGenericoServiceImp<Transferencia, Long>
        implements ITransferenciaService {

    private final TransferenciaRepository repo;
    private final VehiculoRepository vehiculoRepo;

    @Override
    protected ICrudGenericoRepository<Transferencia, Long> getRepo() {
        return repo;
    }

    // El nuevo propietario debe ser distinto al actual. El repositorio, además de guardar
    // la transferencia, actualiza el propietario del vehículo en la misma transacción.
    @Override
    public Transferencia save(Transferencia t) {
        Vehiculo vehiculo = vehiculoRepo.findById(t.getVehiculo().getPlaca())
                .orElseThrow(() -> new ModelNotFoundException(
                        "No existe el vehículo " + t.getVehiculo().getPlaca()));
        if (vehiculo.getPropietario().getDni().equals(t.getNuevoPropietario().getDni())) {
            throw new ReglaNegocioException("El nuevo propietario ya es el propietario actual del vehículo");
        }
        return super.save(t);
    }
}
