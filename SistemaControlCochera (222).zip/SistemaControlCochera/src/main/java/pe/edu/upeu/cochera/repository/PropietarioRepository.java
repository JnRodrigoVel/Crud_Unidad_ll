package pe.edu.upeu.cochera.repository;

import pe.edu.upeu.cochera.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class PropietarioRepository extends AbstractJpaRepository<Propietario, String> {

    @Override protected String getTableName() { return "propietario"; }
    @Override protected String getPkColumn() { return "dni"; }

    @Override
    public List<Propietario> findAll() {
        return executeQuery("SELECT * FROM propietario ORDER BY nombre");
    }

    @Override
    protected Propietario mapRow(ResultSet rs) throws SQLException {
        return Propietario.builder()
                .dni(rs.getString("dni"))
                .nombre(rs.getString("nombre"))
                .direccion(rs.getString("direccion"))
                .celular(rs.getString("celular"))
                .build();
    }

    @Override
    protected Propietario insert(Connection conn, Propietario e) throws SQLException {
        executeUpdate(conn, "INSERT INTO propietario(dni,nombre,direccion,celular) VALUES(?,?,?,?)",
                e.getDni(), e.getNombre(), e.getDireccion(), e.getCelular());
        return e;
    }

    @Override
    protected Propietario updateRow(Connection conn, Propietario e) throws SQLException {
        executeUpdate(conn, "UPDATE propietario SET nombre=?,direccion=?,celular=? WHERE dni=?",
                e.getNombre(), e.getDireccion(), e.getCelular(), e.getDni());
        return e;
    }
}
