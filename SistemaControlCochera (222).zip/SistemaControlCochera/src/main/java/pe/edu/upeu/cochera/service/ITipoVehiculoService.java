package pe.edu.upeu.cochera.service;

import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.model.TipoVehiculo;

import java.util.List;

public interface ITipoVehiculoService extends ICrudGenericoService<TipoVehiculo, Long> {
    List<ComboBoxOption> listarCombobox();
}
