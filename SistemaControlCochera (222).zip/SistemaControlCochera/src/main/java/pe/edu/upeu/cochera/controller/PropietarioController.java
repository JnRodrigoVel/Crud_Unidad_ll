package pe.edu.upeu.cochera.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.components.ColumnInfo;
import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.model.Propietario;
import pe.edu.upeu.cochera.service.ICrudGenericoService;
import pe.edu.upeu.cochera.service.IPropietarioService;

import java.util.LinkedHashMap;
import java.util.Map;

@RequiredArgsConstructor
public class PropietarioController extends BaseCrudController<Propietario, String> {

    private final IPropietarioService ps;

    @FXML TextField txtDni, txtNombre, txtDireccion, txtCelular;

    @Override
    protected void prepararFormulario() {
        txtDni.setTextFormatter(soloDigitos(8));
        txtCelular.setTextFormatter(soloDigitos(9));
    }

    @Override protected ICrudGenericoService<Propietario, String> servicio() { return ps; }

    @Override
    protected LinkedHashMap<String, ColumnInfo> columnas() {
        LinkedHashMap<String, ColumnInfo> c = new LinkedHashMap<>();
        c.put("DNI", new ColumnInfo("dni", 100.0));
        c.put("Nombre", new ColumnInfo("nombre", 220.0));
        c.put("Dirección", new ColumnInfo("direccion", 220.0));
        c.put("Celular", new ColumnInfo("celular", 110.0));
        return c;
    }

    @Override
    protected Propietario leerFormulario() {
        return Propietario.builder()
                .dni(enEdicion != null ? enEdicion.getDni() : texto(txtDni))
                .nombre(texto(txtNombre))
                .direccion(texto(txtDireccion))
                .celular(texto(txtCelular))
                .build();
    }

    @Override
    protected void llenarFormulario(Propietario p) {
        txtDni.setText(p.getDni());
        txtNombre.setText(p.getNombre());
        txtDireccion.setText(p.getDireccion());
        txtCelular.setText(p.getCelular());
    }

    @Override
    protected void limpiarCampos() {
        txtDni.clear(); txtNombre.clear(); txtDireccion.clear(); txtCelular.clear();
    }

    @Override protected void alEditar(Propietario p) { txtDni.setDisable(true); }   // el DNI no se modifica
    @Override protected void alCancelar() { txtDni.setDisable(false); }

    @Override
    protected Map<String, Control> camposValidables() {
        Map<String, Control> m = new LinkedHashMap<>();
        m.put("dni", txtDni);
        m.put("nombre", txtNombre);
        m.put("direccion", txtDireccion);
        m.put("celular", txtCelular);
        return m;
    }

    @Override protected String idDe(Propietario p) { return p.getDni(); }

    @Override
    protected boolean coincideFiltro(Propietario p, String f) {
        return p.getDni().toLowerCase().contains(f) || p.getNombre().toLowerCase().contains(f);
    }

    @Override
    protected String descripcion(Propietario p) { return "al propietario " + p.getNombre() + " (DNI " + p.getDni() + ")"; }
}
