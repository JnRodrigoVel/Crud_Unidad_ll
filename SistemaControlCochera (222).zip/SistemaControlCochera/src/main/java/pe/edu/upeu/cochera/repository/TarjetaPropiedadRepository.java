package pe.edu.upeu.cochera.repository;

import pe.edu.upeu.cochera.model.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class TarjetaPropiedadRepository extends AbstractJpaRepository<TarjetaPropiedad, Long> {

    private static final String SELECT_JOIN =
            "SELECT t.*, v.modelo AS veh_modelo FROM tarjeta_propiedad t " +
                    "JOIN vehiculo v ON t.placa = v.placa ";

    @Override protected String getTableName() { return "tarjeta_propiedad"; }
    @Override protected String getPkColumn() { return "id_tarjeta"; }

    @Override
    public List<TarjetaPropiedad> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY t.placa");
    }

    @Override
    public Optional<TarjetaPropiedad> findById(Long id) {
        return executeQueryOne(SELECT_JOIN + "WHERE t.id_tarjeta = ?", id);
    }

    public Optional<TarjetaPropiedad> buscarPorNumero(String nroTarjeta) {
        return executeQueryOne(SELECT_JOIN + "WHERE t.nro_tarjeta = ?", nroTarjeta);
    }

    @Override
    protected TarjetaPropiedad mapRow(ResultSet rs) throws SQLException {
        return TarjetaPropiedad.builder()
                .idTarjeta(rs.getLong("id_tarjeta"))
                .vehiculo(Vehiculo.builder()
                        .placa(rs.getString("placa"))
                        .modelo(rs.getString("veh_modelo")).build())
                .nroTarjeta(rs.getString("nro_tarjeta"))
                .fechaEmision(getFecha(rs, "fecha_emision"))
                .build();
    }

    @Override
    protected TarjetaPropiedad insert(Connection conn, TarjetaPropiedad e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO tarjeta_propiedad(placa,nro_tarjeta,fecha_emision) VALUES(?,?,?)",
                e.getVehiculo().getPlaca(), e.getNroTarjeta(), e.getFechaEmision());
        e.setIdTarjeta(id);
        return e;
    }

    @Override
    protected TarjetaPropiedad updateRow(Connection conn, TarjetaPropiedad e) throws SQLException {
        executeUpdate(conn,
                "UPDATE tarjeta_propiedad SET placa=?,nro_tarjeta=?,fecha_emision=? WHERE id_tarjeta=?",
                e.getVehiculo().getPlaca(), e.getNroTarjeta(), e.getFechaEmision(), e.getIdTarjeta());
        return e;
    }
}
