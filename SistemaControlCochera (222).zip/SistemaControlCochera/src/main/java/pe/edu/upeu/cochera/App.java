package pe.edu.upeu.cochera;

import javafx.application.Application;

public class App {
    public static void main(String[] args) {
        Application.launch(SistemaCochera.class, args);
    }
}
