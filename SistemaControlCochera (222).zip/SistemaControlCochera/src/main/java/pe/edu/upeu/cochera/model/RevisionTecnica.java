package pe.edu.upeu.cochera.model;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.cochera.enums.EstadoVigencia;
import pe.edu.upeu.cochera.enums.ResultadoRevision;
import pe.edu.upeu.cochera.utils.FechaUtil;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RevisionTecnica {
    private Long idRevision;
    @NotNull(message = "El vehículo es obligatorio")
    private Vehiculo vehiculo;
    @NotBlank(message = "El número de certificado es obligatorio")
    @Size(max = 20, message = "El número de certificado admite máximo 20 caracteres")
    private String nroCertificado;
    @NotNull(message = "La fecha de revisión es obligatoria")
    private LocalDate fechaRevision;
    @NotNull(message = "La fecha de vencimiento es obligatoria")
    private LocalDate fechaVencimiento;
    @NotNull(message = "El resultado es obligatorio")
    private ResultadoRevision resultado;

    @AssertTrue(message = "El vencimiento debe ser posterior a la fecha de revisión")
    public boolean isVigenciaValida() {
        return fechaRevision == null || fechaVencimiento == null || fechaVencimiento.isAfter(fechaRevision);
    }

    public String getFechaRevisionTxt() {
        return FechaUtil.formatear(fechaRevision);
    }

    public String getFechaVencimientoTxt() {
        return FechaUtil.formatear(fechaVencimiento);
    }

    public Long getDiasRestantes() {
        return EstadoVigencia.diasRestantes(fechaVencimiento);
    }

    public String getEstado() {
        return EstadoVigencia.de(fechaVencimiento).getDescripcion();
    }
}
