package pe.edu.upeu.cochera.config;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

/**
 * Datos iniciales. Cada tabla se llena solo si está vacía, así que no pisa lo que
 * el usuario ya haya registrado. Los ids se generan solos (1, 2, 3...) en el orden
 * en que se insertan, por eso las tablas hijas pueden referenciarlos.
 */
final class DatabaseSeeder {

    private DatabaseSeeder() {
    }

    static void sembrar(DataSource ds) {
        try (Connection c = ds.getConnection()) {
            c.setAutoCommit(false);
            try {
                if (vacia(c, "perfil")) {
                    ejecutar(c, "INSERT INTO perfil(nombre,codigo) VALUES(?,?)", "Root", "ROOT");
                    ejecutar(c, "INSERT INTO perfil(nombre,codigo) VALUES(?,?)", "Administrador", "ADM");
                    ejecutar(c, "INSERT INTO perfil(nombre,codigo) VALUES(?,?)", "Reporte", "REP");
                }
                if (vacia(c, "usuario")) {
                    String sql = "INSERT INTO usuario(usuario,clave,estado,id_perfil) VALUES(?,?,?,?)";
                    ejecutar(c, sql, "admin", "admin123", "ACTIVO", 1);
                    ejecutar(c, sql, "operador", "operador123", "ACTIVO", 2);
                    ejecutar(c, sql, "consulta", "consulta123", "ACTIVO", 3);
                }
                if (vacia(c, "marca")) {
                    for (String m : new String[]{"Toyota", "Hyundai", "Kia", "Nissan"}) {
                        ejecutar(c, "INSERT INTO marca(nombre) VALUES(?)", m);
                    }
                }
                if (vacia(c, "tipo_vehiculo")) {
                    for (String t : new String[]{"Automóvil", "Camioneta", "Motocicleta", "Camión"}) {
                        ejecutar(c, "INSERT INTO tipo_vehiculo(nombre) VALUES(?)", t);
                    }
                }
                if (vacia(c, "propietario")) {
                    String sql = "INSERT INTO propietario(dni,nombre,direccion,celular) VALUES(?,?,?,?)";
                    ejecutar(c, sql, "45871236", "Ana Quispe", "Jr. Lima 123", "951234567");
                    ejecutar(c, sql, "70123456", "Luis Mamani", "Av. Circunvalación 456", "952345678");
                    ejecutar(c, sql, "42987654", "Rosa Condori", "Jr. Puno 789", "953456789");
                }
                if (vacia(c, "vehiculo")) {
                    String sql = "INSERT INTO vehiculo(placa,id_marca,id_tipo,dni,modelo,anio,color,nro_motor) "
                            + "VALUES(?,?,?,?,?,?,?,?)";
                    ejecutar(c, sql, "ABC-123", 1, 1, "45871236", "Yaris", 2019, "BLANCO", "1NZ1234567");
                    ejecutar(c, sql, "V4X-812", 2, 1, "70123456", "Accent", 2021, "GRIS", "G4LC123456");
                    ejecutar(c, sql, "D2F-556", 3, 1, "42987654", "Rio", 2017, "ROJO", "G4FA765432");
                }
                LocalDate hoy = LocalDate.now();
                if (vacia(c, "tarjeta_propiedad")) {
                    String sql = "INSERT INTO tarjeta_propiedad(placa,nro_tarjeta,fecha_emision) VALUES(?,?,?)";
                    ejecutar(c, sql, "ABC-123", "TP-0001234", hoy.minusYears(3));
                    ejecutar(c, sql, "V4X-812", "TP-0005678", hoy.minusYears(1));
                    ejecutar(c, sql, "D2F-556", "TP-0009012", hoy.minusYears(5));
                }
                if (vacia(c, "soat")) {
                    String sql = "INSERT INTO soat(placa,nro_poliza,aseguradora,fecha_inicio,fecha_vencimiento) "
                            + "VALUES(?,?,?,?,?)";
                    ejecutar(c, sql, "ABC-123", "SOAT-0001234", "Rímac Seguros", hoy.minusDays(200), hoy.plusDays(165));
                    ejecutar(c, sql, "V4X-812", "SOAT-0005678", "Pacífico Seguros", hoy.minusDays(350), hoy.plusDays(15));
                    ejecutar(c, sql, "D2F-556", "SOAT-0009012", "La Positiva", hoy.minusDays(400), hoy.minusDays(35));
                }
                if (vacia(c, "revision_tecnica")) {
                    String sql = "INSERT INTO revision_tecnica(placa,nro_certificado,fecha_revision,fecha_vencimiento,resultado) "
                            + "VALUES(?,?,?,?,?)";
                    ejecutar(c, sql, "ABC-123", "CITV-0001001", hoy.minusDays(100), hoy.plusDays(265), "APROBADO");
                    ejecutar(c, sql, "V4X-812", "CITV-0001002", hoy.minusDays(340), hoy.plusDays(25), "APROBADO");
                    ejecutar(c, sql, "D2F-556", "CITV-0001003", hoy.minusDays(400), hoy.minusDays(35), "OBSERVADO");
                }
                c.commit();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Error al cargar los datos iniciales", e);
        }
    }

    private static boolean vacia(Connection c, String tabla) throws SQLException {
        try (Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM " + tabla)) {
            rs.next();
            return rs.getLong(1) == 0;
        }
    }

    private static void ejecutar(Connection c, String sql, Object... params) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                ps.setObject(i + 1, params[i]);
            }
            ps.executeUpdate();
        }
    }
}
