package pe.edu.upeu.cochera.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.cochera.components.ColumnInfo;
import pe.edu.upeu.cochera.components.ComboBoxAutoComplete;
import pe.edu.upeu.cochera.dto.ComboBoxOption;
import pe.edu.upeu.cochera.dto.SessionManager;
import pe.edu.upeu.cochera.model.Transferencia;
import pe.edu.upeu.cochera.model.Usuario;
import pe.edu.upeu.cochera.model.Vehiculo;
import pe.edu.upeu.cochera.service.*;
import pe.edu.upeu.cochera.utils.FechaUtil;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

@RequiredArgsConstructor
public class TransferenciaController extends BaseCrudController<Transferencia, Long> {

    private final ITransferenciaService ts;
    private final IVehiculoService vs;
    private final IPropietarioService ps;
    private final IUsuarioService us;

    @FXML ComboBox<ComboBoxOption> cbxVehiculo, cbxNuevoPropietario;
    @FXML TextField txtPropActual, txtMonto, txtUsuario;
    @FXML DatePicker dpFecha;

    @Override
    protected void prepararFormulario() {
        cbxVehiculo.getItems().addAll(vs.listarCombobox());
        cbxNuevoPropietario.getItems().addAll(ps.listarCombobox());
        new ComboBoxAutoComplete<>(cbxVehiculo);
        new ComboBoxAutoComplete<>(cbxNuevoPropietario);
        FechaUtil.configurar(dpFecha);
        dpFecha.setValue(LocalDate.now());
        txtMonto.setTextFormatter(new TextFormatter<String>(c ->
                c.getControlNewText().matches("\\d{0,8}(\\.\\d{0,2})?") ? c : null));
        txtUsuario.setText(SessionManager.getInstance().getUserName());

        // al elegir el vehículo se muestra su propietario actual
        cbxVehiculo.valueProperty().addListener((obs, anterior, elegido) -> {
            if (elegido == null) {
                txtPropActual.clear();
            } else {
                Vehiculo v = vs.findById(elegido.getKey());
                txtPropActual.setText(v.getPropietario().getDni() + " - " + v.getPropietario().getNombre());
            }
        });
    }

    @Override protected ICrudGenericoService<Transferencia, Long> servicio() { return ts; }

    @Override
    protected LinkedHashMap<String, ColumnInfo> columnas() {
        LinkedHashMap<String, ColumnInfo> c = new LinkedHashMap<>();
        c.put("ID", new ColumnInfo("idTransf", 50.0));
        c.put("Placa", new ColumnInfo("vehiculo.placa", 100.0));
        c.put("Nuevo propietario", new ColumnInfo("nuevoPropietario.nombre", 180.0));
        c.put("Fecha", new ColumnInfo("fechaTransfTxt", 100.0));
        c.put("Monto", new ColumnInfo("monto", 90.0));
        c.put("Registrado por", new ColumnInfo("usuario.usuario", 120.0));
        return c;
    }

    @Override
    protected Transferencia leerFormulario() {
        return Transferencia.builder()
                .idTransf(enEdicion != null ? enEdicion.getIdTransf() : null)
                .vehiculo(elegido(cbxVehiculo, placa -> Vehiculo.builder().placa(placa).build()))
                .nuevoPropietario(elegido(cbxNuevoPropietario, ps::findById))
                .fechaTransf(fecha(dpFecha))
                .monto(leerMonto())
                .usuario(usuarioEnSesion())
                .build();
    }

    private BigDecimal leerMonto() {
        String t = texto(txtMonto);
        if (t.isEmpty()) return null;
        try {
            return new BigDecimal(t);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private Usuario usuarioEnSesion() {
        Long id = SessionManager.getInstance().getUserId();
        if (id == null) return null;
        try {
            return us.findById(id);
        } catch (RuntimeException e) {
            return null;
        }
    }

    @Override
    protected void llenarFormulario(Transferencia t) {
        seleccionar(cbxVehiculo, t.getVehiculo().getPlaca());
        seleccionar(cbxNuevoPropietario, t.getNuevoPropietario().getDni());
        dpFecha.setValue(t.getFechaTransf());
        txtMonto.setText(t.getMonto() == null ? "" : t.getMonto().toPlainString());
    }

    @Override
    protected void limpiarCampos() {
        cbxVehiculo.getSelectionModel().clearSelection();
        cbxNuevoPropietario.getSelectionModel().clearSelection();
        txtPropActual.clear();
        txtMonto.clear();
        dpFecha.setValue(LocalDate.now());
    }

    // al corregir una transferencia solo se cambian fecha y monto
    @Override
    protected void alEditar(Transferencia t) {
        cbxVehiculo.setDisable(true);
        cbxNuevoPropietario.setDisable(true);
    }

    @Override
    protected void alCancelar() {
        cbxVehiculo.setDisable(false);
        cbxNuevoPropietario.setDisable(false);
    }

    @Override
    protected Map<String, Control> camposValidables() {
        Map<String, Control> m = new LinkedHashMap<>();
        m.put("vehiculo", cbxVehiculo);
        m.put("nuevoPropietario", cbxNuevoPropietario);
        m.put("fechaTransf", dpFecha);
        m.put("monto", txtMonto);
        return m;
    }

    @Override protected Long idDe(Transferencia t) { return t.getIdTransf(); }

    @Override
    protected boolean coincideFiltro(Transferencia t, String f) {
        return t.getVehiculo().getPlaca().toLowerCase().contains(f)
                || t.getNuevoPropietario().getNombre().toLowerCase().contains(f);
    }

    @Override
    protected String descripcion(Transferencia t) {
        return "la transferencia del vehículo " + t.getVehiculo().getPlaca()
                + " (esto no devuelve el vehículo al propietario anterior)";
    }
}
