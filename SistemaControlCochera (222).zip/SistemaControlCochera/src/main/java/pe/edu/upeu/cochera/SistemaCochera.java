package pe.edu.upeu.cochera;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import pe.edu.upeu.cochera.config.AppContext;
import pe.edu.upeu.cochera.config.DatabaseConfig;

import java.io.IOException;

public class SistemaCochera extends Application {

    @Override
    public void start(Stage stage) throws IOException {
        try {
            DatabaseConfig.init();
        } catch (RuntimeException e) {
            Alert alerta = new Alert(Alert.AlertType.ERROR,
                    "No se pudo abrir la base de datos:\n" + e.getMessage());
            alerta.setHeaderText(null);
            alerta.showAndWait();
            return;
        }
        AppContext appContext = AppContext.getInstance();
        FXMLLoader fxmlLoader = new FXMLLoader(SistemaCochera.class.getResource("/view/login.fxml"));
        fxmlLoader.setControllerFactory(appContext::getBean);
        Scene scene = new Scene(fxmlLoader.load());
        scene.getStylesheets().add(SistemaCochera.class.getResource("/css/style.css").toExternalForm());
        stage.setTitle("Sistema de Control Cochera");
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }

    @Override
    public void stop() {
        DatabaseConfig.shutdown();
    }
}
