package pe.edu.upeu.cochera.service;

import pe.edu.upeu.cochera.dto.MenuMenuItenTO;

import java.util.List;
import java.util.Map;

public interface IMenuMenuItemDao {
    /** Opciones de menú a las que puede entrar el perfil indicado. */
    List<MenuMenuItenTO> listaAccesos(String perfil);

    /** id del MenuItem → {ruta fxml, título de la pestaña, tipo (T = pestaña, C = cerrar sesión)}. */
    Map<String, String[]> accesosAutorizados(List<MenuMenuItenTO> accesos);
}
