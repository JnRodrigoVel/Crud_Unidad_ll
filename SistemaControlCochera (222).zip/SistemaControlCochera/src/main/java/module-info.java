module pe.edu.upeu.cochera {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires static lombok;
    requires jakarta.validation;

    requires java.sql;
    requires java.naming;
    requires org.slf4j;
    requires com.zaxxer.hikari;

    opens pe.edu.upeu.cochera to javafx.fxml;
    opens pe.edu.upeu.cochera.controller to javafx.fxml;
    opens pe.edu.upeu.cochera.model;
    opens pe.edu.upeu.cochera.dto;
    exports pe.edu.upeu.cochera;
}
