# Sistema de Control Cochera

JavaFX + H2 + HikariCP + Lombok, con la misma arquitectura de SysVentas
(`AppContext` → repositorios JDBC → servicios → controladores → FXML).

## Ejecutar
Abre una terminal **dentro de la carpeta que contiene `pom.xml` y `mvnw.cmd`** (la carpeta ya descomprimida) y ejecuta:
```
Windows (CMD):         mvnw.cmd clean javafx:run
Windows (PowerShell):  .\mvnw.cmd clean javafx:run
Mac / Linux:           ./mvnw clean javafx:run
```
Requiere Java instalado (JAVA_HOME configurado) e internet la primera vez.
Desde un IDE: abre la carpeta como proyecto Maven y ejecuta `App.java`, o usa Maven > Plugins > javafx > `javafx:run`.
La base se crea sola en la carpeta de tu usuario: `~/SistemaControlCochera/data` (en Windows: `C:\Users\TuUsuario\SistemaControlCochera\data`) (esquema en `schema_cochera.sql`, datos de ejemplo en `DatabaseSeeder`).

## Usuarios de ejemplo
| Usuario  | Clave        | Perfil        |
|----------|--------------|---------------|
| admin    | admin123     | Root          |
| operador | operador123  | Administrador |
| consulta | consulta123  | Reporte       |

## Tablas (según `sistema_control_cochera.architect`)
perfil, usuario, propietario, marca, tipo_vehiculo, vehiculo, transferencia,
tarjeta_propiedad, soat, revision_tecnica.

## Pantallas
- **Principal**: alertas de SOAT / revisión técnica vencidos o por vencer (30 días).
- **Registros**: propietarios, marcas, tipos de vehículo, vehículos.
- **Documentos**: tarjeta de propiedad, SOAT, revisión técnica (con estado y días restantes).
- **Movimientos**: transferencias (al registrar una, el vehículo cambia de propietario).
- **Seguridad**: usuarios (solo Root).
